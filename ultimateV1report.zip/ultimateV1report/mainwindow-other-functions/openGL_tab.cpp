// file dove si trovano definite le varie funzioni dichiarate nella classe mainwindow.h, in breve qui si trovano scritte le funzioni
// che gestiscono
// - creazione degli oggetti MyGLWidget, quindi schermi openGL
// - connessioni tra oggetti del mainwindow e oggetto MyGLWidget

#include "../mainwindow.h"
#include "ui_mainwindow.h"


// sarebbe lo slot connesso al segnale di databridge, appena lo slot viene eseguito si genera l'interfaccia openGL sulla base dei settaggi che
// sono stati inviati dal segnale
void MainWindow::setupGLscreens(decoders_setup_data data){
    // quando mi arrivano questi dati posso effettivamente iniziare a costruire l'interfaccia openGL
    // l'idea è inserire tutta una logica che in base ai dati in data aggiusta l'interfaccia, il punto ora è
    // capire come si interpretano i dati che arrivano, per ora implemento una logica semplicissima che:
    // per EMG considera solo numero di sottocanali attivi e frequenza di campionamento
    // per GYR considera solo frequenza di campionamento

    //-----
    qDebug() << "data.datarateEMG (EMG): " << data.datarateEMG;
    qDebug() << "data.channels (EMG): " << data.channels;
    qDebug() << "data.config (EMG): " << data.config;

    qDebug() << "data.datarateGYR (GYR): " << data.datarateGYR;
    qDebug() << "data.acc_range (GYR): " << data.acc_range;
    qDebug() << "data.gyr_range (GYR): " << data.gyr_range;
    //-----

    // setup schermi giroscopio,
    // replace + connect alle corrispettive pulsantiere + connect dei segnali uscenti dai vari schermi agli slot
    ogl_screen_gyr_temp = replaceOpenGLscreen((ui->GYRtemp_screen_grid->itemAtPosition(0, 1))->widget(),
                                              ui->GYRtemp_screen_grid,
                                              10.0, 30, -30, "°C", data.datarateGYR, 0.1, {{RED}}, 6, 10);
    connectInputToOpenGLscreen(ogl_screen_gyr_temp,
                               ui->GYRtemp_t_scale_inc, ui->GYRtemp_t_scale_dec, ui->GYRtemp_v_scale_inc, ui->GYRtemp_v_scale_dec,
                               ui->GYRtemp_static_selector, ui->GYRtemp_static_slider, nullptr);
    connectSignalsFromOpenGLscreen(ogl_screen_gyr_temp,
                                   &MainWindow::updateTscaleLabelGYRtemp,
                                   &MainWindow::updateVscaleLabelGYRtemp,
                                   &MainWindow::updateLogGYRtemp,
                                   &MainWindow::updateModGYRtemp,
                                   &MainWindow::updateTimeGYRtemp);
    connect(dataOut, &dataBridge::GYRdataTemp, ogl_screen_gyr_temp, &MyGLWidget::loadDatabuffer);



    ogl_screen_gyr_vel = replaceOpenGLscreen((ui->GYRvel_screen_grid->itemAtPosition(0, 1))->widget(),
                                             ui->GYRvel_screen_grid,
                                             30.0, 500, -500, "°/s", data.datarateGYR, 0.1, {{RED,GREEN,BLUE}}, 6, 10);
    connectInputToOpenGLscreen(ogl_screen_gyr_vel,
                               ui->GYRvel_t_scale_inc, ui->GYRvel_t_scale_dec, ui->GYRvel_v_scale_inc, ui->GYRvel_v_scale_dec,
                               ui->GYRvel_static_selector, ui->GYRvel_static_slider, nullptr);
    connectSignalsFromOpenGLscreen(ogl_screen_gyr_vel,
                                   &MainWindow::updateTscaleLabelGYRvel,
                                   &MainWindow::updateVscaleLabelGYRvel,
                                   &MainWindow::updateLogGYRvel,
                                   &MainWindow::updateModGYRvel,
                                   &MainWindow::updateTimeGYRvel);
    connect(dataOut, &dataBridge::GYRdataVel, ogl_screen_gyr_vel, &MyGLWidget::loadDatabuffer);


    ogl_screen_gyr_acc = replaceOpenGLscreen((ui->GYRacc_screen_grid->itemAtPosition(0, 1))->widget(),
                                             ui->GYRacc_screen_grid,
                                             30.0, 10, -10, "g", data.datarateGYR, 0.1, {{RED,GREEN,BLUE}}, 6, 10);

    connectInputToOpenGLscreen(ogl_screen_gyr_acc,
                               ui->GYRacc_t_scale_inc, ui->GYRacc_t_scale_dec, ui->GYRacc_v_scale_inc, ui->GYRacc_v_scale_dec,
                               ui->GYRacc_static_selector, ui->GYRacc_static_slider, nullptr);
    connectSignalsFromOpenGLscreen(ogl_screen_gyr_acc,
                                   &MainWindow::updateTscaleLabelGYRacc,
                                   &MainWindow::updateVscaleLabelGYRacc,
                                   &MainWindow::updateLogGYRacc,
                                   &MainWindow::updateModGYRacc,
                                   &MainWindow::updateTimeGYRacc);
    connect(dataOut, &dataBridge::GYRdataAcc, ogl_screen_gyr_acc, &MyGLWidget::loadDatabuffer);



    // setup degli schermi EMG, replace degli schermi che effettivamente servono + connessioni e rimozione degli schermi placeholder non necessari.
    // devo effettuare anche una riscrittura della label per far capire da quali elettrodi il segnale è stato rilevato.

    // in config si trovano scritti nei 3 byte finali le configurazioni dei "canali", se sono attivi solo 2 canali allora mi basterà leggere solo il byte
    // 1 e il byte 2 perchè comunque il 3 è vuoto. (VERIFICATO)
    QString screen_label;
    uint8_t mode;


    // riscrittura label e replace schermo
    screen_label = "EMG/ECG - Electrodes used:";
    mode = data.config >> (8 * 1);
    screen_label += QString::number(mode >> 3) + "-" + QString::number(mode & 7);
    ui->EMG_screen1_label->setText(screen_label);
    ogl_screen_emg_1 = replaceOpenGLscreen((ui->EMG_grid_screen1->itemAtPosition(0, 1))->widget(),
                                           ui->EMG_grid_screen1,
                                           10.0, 0.04, -0.04, "V", data.datarateEMG, 5, {{RED}}, 6, 10);

    // connessione dello schermo alla pulsantiera EMG, ricorda che EMG i tre canali sono gestiti da una sola pulsantiera
    connectInputToOpenGLscreen(ogl_screen_emg_1,
                               ui->EMG_t_scale_inc, ui->EMG_t_scale_dec, ui->EMG_v_scale_inc, ui->EMG_v_scale_dec,
                               ui->EMG_static_selector, ui->EMG_static_slider, ui->EMG_high_pass_filter_button);
    // connessione per portare i dati dentro lo schermo
    connect(dataOut, &dataBridge::EMGdataScreen1, ogl_screen_emg_1, &MyGLWidget::loadDatabuffer);



    // riscrittura label e replace schermo
    screen_label = "EMG/ECG - Electrodes used:";
    mode = data.config >> (8 * 2);
    screen_label += QString::number(mode >> 3) + "-" + QString::number(mode & 7);
    ui->EMG_screen2_label->setText(screen_label);
    ogl_screen_emg_2 = replaceOpenGLscreen((ui->EMG_grid_screen2->itemAtPosition(0, 1))->widget(),
                                           ui->EMG_grid_screen2,
                                           10.0, 0.04, -0.04, "V", data.datarateEMG, 5, {{RED}}, 6, 10);
    // connessione dello schermo alla pulsantiera EMG, ricorda che EMG i tre canali sono gestiti da una sola pulsantiera
    connectInputToOpenGLscreen(ogl_screen_emg_2,
                               ui->EMG_t_scale_inc, ui->EMG_t_scale_dec, ui->EMG_v_scale_inc, ui->EMG_v_scale_dec,
                               ui->EMG_static_selector, ui->EMG_static_slider, ui->EMG_high_pass_filter_button);
    // connessione per portare i dati dentro lo schermo
    connect(dataOut, &dataBridge::EMGdataScreen2, ogl_screen_emg_2, &MyGLWidget::loadDatabuffer);


    // riscrittura label e replace schermo
    screen_label = "EMG/ECG - Electrodes used:";
    mode = data.config >> (8 * 3);
    screen_label += QString::number(mode >> 3) + "-" + QString::number(mode & 7);
    ui->EMG_screen3_label->setText(screen_label);
    ogl_screen_emg_3 = replaceOpenGLscreen((ui->EMG_grid_screen3->itemAtPosition(0, 1))->widget(),
                                           ui->EMG_grid_screen3,
                                           10.0, 0.04, -0.04, "V", data.datarateEMG, 5, {{RED}}, 6, 10);
    // connessione dello schermo alla pulsantiera EMG, ricorda che EMG i tre canali sono gestiti da una sola pulsantiera
    connectInputToOpenGLscreen(ogl_screen_emg_3,
                               ui->EMG_t_scale_inc, ui->EMG_t_scale_dec, ui->EMG_v_scale_inc, ui->EMG_v_scale_dec,
                               ui->EMG_static_selector, ui->EMG_static_slider, ui->EMG_high_pass_filter_button);
    // connessione per portare i dati dentro lo schermo
    connect(dataOut, &dataBridge::EMGdataScreen3, ogl_screen_emg_3, &MyGLWidget::loadDatabuffer);


    // inoltre, essendo che sono sicuro che ci sarà sempre almeno 1 effettuo le connessioni che vanno dallo schermo alla main window,
    // ricordiamo che il caso EMG è particolare perche possiede una sola pulsantiera che gestisce tutti gli schermi e ogni
    // schermo possiede dei segnali che vanno connessi alla main window e servono per aggiornare le label della pulsantiera però in ques
    // to caso è inutile connettere i segnali di ogni schermo, bastano quelli di uno.
    connectSignalsFromOpenGLscreen(ogl_screen_emg_1);
}



// funzione per fare il replace in modo "pulito" di uno schermo openGL
MyGLWidget* MainWindow::replaceOpenGLscreen(QWidget* old_OpenGLscreen,
                                            QGridLayout* layout,
                                            double t_range_max, double v_max, double v_min, QString v_unit,
                                            float fc, double ft,
                                            std::vector<std::vector<GLfloat>> tcolors,
                                            unsigned int division_for_v_axi, unsigned int division_for_h_axi)
{
    // qDebug() << "ok";
    layout->removeWidget(old_OpenGLscreen);
    old_OpenGLscreen->disconnect();
    delete old_OpenGLscreen;
    layout->update();

    MyGLWidget* new_ogl_screen = new MyGLWidget(this, t_range_max, v_max, v_min, v_unit, fc, ft, tcolors, division_for_v_axi, division_for_h_axi);

    new_ogl_screen->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    new_ogl_screen->setFixedHeight(200);
    // la griglia è un po strana
    layout->addWidget(new_ogl_screen, 0, 1);


    return new_ogl_screen;
}


void MainWindow::connectInputToOpenGLscreen(MyGLWidget* screen,
                                QPushButton* t_scale_inc, QPushButton* t_scale_dec, QPushButton* v_scale_inc, QPushButton* v_scale_dec,
                                QPushButton* static_selector, QSlider* static_slider, QPushButton* filter_mod){
    // connessioni pulsanti interfaccia - slot oggetto MyGLWidget, sono collegamenti necessari se si vuole modificare ciò
    // che viene mostrato sullo schermo openGL, in altre parole questi collegamenti modificano lo stato interno dell'oggetto
    // schermo openGL
    connect(t_scale_inc, &QPushButton::clicked, screen, &MyGLWidget::modifyTscaleInc);
    connect(t_scale_dec, &QPushButton::clicked, screen, &MyGLWidget::modifyTscaleDec);
    connect(v_scale_inc, &QPushButton::clicked, screen, &MyGLWidget::modifyVscaleInc);
    connect(v_scale_dec, &QPushButton::clicked, screen, &MyGLWidget::modifyVscaleDec);

    connect(static_selector, &QPushButton::toggled, screen, &MyGLWidget::modifyMod);

    connect(static_slider, &QSlider::valueChanged, screen, &MyGLWidget::modifyTimeWindow);

    if(filter_mod != nullptr) connect(filter_mod, &QPushButton::toggled, screen, &MyGLWidget::modifyFilterMod);

}


void MainWindow::connectSignalsFromOpenGLscreen(MyGLWidget* screen,
                                    void (MainWindow::*updateTS)(QString), void (MainWindow::*updateVS)(QString, QString, QString),
                                    void (MainWindow::*updateLog)(QString),
                                    void (MainWindow::*updateMod)(QString),
                                    void (MainWindow::*updateTime)(QString, QString, QString)){


    connect(screen, &MyGLWidget::TscaleUpdated, this, updateTS);
    connect(screen, &MyGLWidget::VscaleUpdated, this, updateVS);
    connect(screen, &MyGLWidget::ModUpdated, this, updateMod);
    connect(screen, &MyGLWidget::TimeUpdated, this, updateTime);
    connect(screen, &MyGLWidget::LogUpdated, this, updateLog);

}

