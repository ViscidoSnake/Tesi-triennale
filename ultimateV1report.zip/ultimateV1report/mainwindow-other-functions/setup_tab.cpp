// file dove si trovano definite le varie funzioni dichiarate nella classe mainwindow.h, in breve qui si trovano scritte le funzioni
// che gestiscono ricerca dei device BLE, connessione al device BLE, disconnessione e aggiornamento del riquadro di log

#include "../mainwindow.h"
#include "ui_mainwindow.h"


// slot per oggetti nell' interfaccia

// slot per abilitare nuovamente la scansione e tentativo di connessione, lo utilizza la classe MyEMGyro2
// una volta che la connessione è stata chiusa
void MainWindow::ableScanAndConnection(){
    // distruggo l'oggetto device (istanza alla classe MyGyro), tale distruzione in questo punto permette di garantire che ogni volta
    // che si permette una nuova riesecuzione della ricerca poi connessione e streaming dei dati, il vecchio oggetto usato sia distrutto in memoria essendo
    // che non verrà più usato ma si verificherà gni volta una nuova istanza.
    // NOTA: ableScanAndConnection viene eseguito sempre perchè la classe MyGyro è costruita in modo tale che anche in caso di errore emetta un segnale
    // a tale slot

    connect(device, &QObject::destroyed, this, [this](QObject* obj){
        // log per avvisare avvenuta rimozione del device
        emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") +"]" +
                        "-[INFO]-[ableScanAndConnection]-[MyEMGyro2]-oggetto usato per la connessione appena terminata distrutto.");
    });
    device->deleteLater();

    // rimuovo tutte le voci dalla tabella e rimuovo gli oggetti memorizati nel vettore facendo un resize, sono operazioni eseguite nel caso
    // in cui MyGyro fallisce la connessione.
    ui->list_of_discovered_devices_table->setRowCount(0);
    device_discovered_list.clear();

    // impostazione dei pulsanti dell'interfaccia nello stato iniziale
    ui->start_scan_button->setDisabled(false);
    ui->stop_scan_button->setDisabled(true);
    ui->connect_button->setDisabled(true);
    ui->disconnect_button->setDisabled(true);
    // rendo non premibili i vari pulsanti nel layout per il filtraggio
    ui->filter_button->setDisabled(true);
    ui->search_bar_lineedit->setDisabled(true);
    ui->name_filter_radiobutton->setDisabled(true);
    ui->nickname_filter_radiobutton->setDisabled(true);

    // riabilito l'interfaccia, serve quando si verifica un errore di connessione e quindi la classe MyGyro2 non emette il segna
    // le che viene gestito da disableScanAndConnection ma direttamente ableScanAndConnection
    ui->tabs->widget(0)->setEnabled(true);

    // log per notificare l'ingresso nella modalita ricerca
    emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") +"]" +
                    "-[SPECIAL INFO]-[ableScanAndConnection]-[QBluetoothDeviceDiscoveryAgent]-Uscita dalla modalità connessa e Ingresso nella modalità "
                    "ricerca.");

}
// slot per disabilitare la scansione e tentativo di connessione, lo utilizza la classe MyEMGyro2 quando riesce a stabile la
// connessione
void MainWindow::disableScanAndConnection(){
    // rimuovo tutte le voci dalla tabella e rimuovo gli oggetti memorizati nel vettore facendo un resize
    ui->list_of_discovered_devices_table->setRowCount(0);
    device_discovered_list.clear();

    // impostazione dei pulsanti dell'interfaccia nello stato di connessione
    ui->start_scan_button->setDisabled(true);
    ui->stop_scan_button->setDisabled(true);
    ui->connect_button->setDisabled(true);
    ui->disconnect_button->setDisabled(false);
    // rendo non premibili i vari pulsanti nel layout per il filtraggio
    ui->filter_button->setDisabled(true);
    ui->search_bar_lineedit->setDisabled(true);
    ui->name_filter_radiobutton->setDisabled(true);
    ui->nickname_filter_radiobutton->setDisabled(true);

    // riabilito l'interfaccia, operazione necessaria perchè in tryToConnectToDevice alla fine disabilito tutto e aspetto la risposta della classe MyGyro
    ui->tabs->widget(0)->setEnabled(true);

    // log per notificare l'ingresso nella modalita connessa
    emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") +"]" +
                    "-[SPECIAL INFO]-[disableScanAndConnection]-[QBluetoothDeviceDiscoveryAgent]-Uscita dalla modalità ricerca e Ingresso nella modalità"
                    " connessa.");
}
// slot per iniziare la scansione per trovare device
void MainWindow::startScan(){
    // creazione agente per ricerca device
    m_discovery_agent = new QBluetoothDeviceDiscoveryAgent(this);
    connect(m_discovery_agent, &QBluetoothDeviceDiscoveryAgent::deviceDiscovered, this, &MainWindow::deviceDiscovered);
    connect(m_discovery_agent, &QBluetoothDeviceDiscoveryAgent::canceled, this, &MainWindow::scanFinished);
    //se uso setLowEnergyDiscoveryTimeout(15000) non viene trovato nulla

    // rimuovo tutte le voci dalla tabella e rimuovo gli oggetti memorizati nel vettore facendo un resize
    ui->list_of_discovered_devices_table->setRowCount(0);
    device_discovered_list.clear();
    // disabilito il pulsante in modo che non possa essere ripremuto ma abilito quello di stop, setto anche i pulsanti per
    // stabilire la connessione/disconnessione
    ui->start_scan_button->setDisabled(true);
    ui->stop_scan_button->setDisabled(false);
    ui->connect_button->setDisabled(true);
    ui->disconnect_button->setDisabled(true);
    // rendo non selezionabili le righe della tabella
    ui->list_of_discovered_devices_table->setSelectionMode(QAbstractItemView::NoSelection);
    // rendo non premibili i vari pulsanti nel layout per il filtraggio
    ui->filter_button->setDisabled(true);
    ui->search_bar_lineedit->setDisabled(true);
    ui->name_filter_radiobutton->setDisabled(true);
    ui->nickname_filter_radiobutton->setDisabled(true);

    // imposto la scansione dei soli dispositivi BLE, in realtà è possibile che vengano presi anche dispositivi non BLE, questo
    // comportamento dipende dal controller bluetooth usato dal PC, in ogni caso mposto questa modalità perche mi semplifica la
    // gestione della scansione infatti facendo setLowEnergyDiscoveryTimeout(0); faccio in modo che la scansione dei dispositivi
    // continui fin tanto che non viene arrestata premndo il pulsante di stop, la modalità standard invece si arresta dopo pochi
    // secondi e lascia l'applicazione in uno stato indefinito, inoltre è probabile che anche i dispositivi trovati non risultino
    // realmente visibili dopo la fine della scansione.

    // il log sotto serve per verificare se il controller bluetooth del pc supporta ricerca di soli device BLE, se non viene
    // mostrato low energy method è un problema
    // qDebug() << m_discovery_agent->QBluetoothDeviceDiscoveryAgent::supportedDiscoveryMethods();
    m_discovery_agent->setLowEnergyDiscoveryTimeout(0);
    // verifico se il controller supporta per la ricerca BLE la scansione continua, se ritorna -1 significa che non è supportata
    // è un problema
    // qDebug() << m_discovery_agent->lowEnergyDiscoveryTimeout();

    // start della scansione, la imposto per cercare solo dispositivi BLE
    m_discovery_agent->start(QBluetoothDeviceDiscoveryAgent::LowEnergyMethod);
    emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") +"]" +
                    "-[SPECIAL INFO]-[startScan]-[QBluetoothDeviceDiscoveryAgent]-Scansione dei device iniziata");


}
// slot per fermare la scansione di device
void MainWindow::stopScan(){
    // essendo un operazione gestita dal discovery Agent non si sa esattamente quanto tempo impiegherà per svolgersi effettivamente, durante questo lasso
    // di tempo, per evitare che l'utente invii input indesiderati si disabilita tutta l'interfaccia
    ui->tabs->widget(0)->setEnabled(false);
    m_discovery_agent->stop();
}
// slot per definire dalla tabella il device a cui ci si vuole connettere
void MainWindow::tryToConnectToDevice(){
    // ricerco nella tabella la righa selezionata e estraggo i dati che mi permettono di risalire all'oggetto device che si trova dentro
    // device_discovered_list
    // selectedRows())[0] restituisce un oggetto QModelIndexList che possiede il metodo row per convertire l'indirizzo in numero
    // della riga nella tabella, selectionModel() restituisce infatti il modello di selezione del widget
    QModelIndexList row_list = ui->list_of_discovered_devices_table->selectionModel()->selectedRows();
    if(!row_list.empty()){
        unsigned int selected_row = row_list[0].row();
        // ora che ho la righa confronto i dati su essa con i dati che possiedono gli oggetti dentro device_discovered_list
        // certamente il dato che ha più senso confrontare è UUID che è univoco per ogni dispositivo.
        QString table_uuid = ui->list_of_discovered_devices_table->item(selected_row, 0)->text();
        for(unsigned int i=0; i < device_discovered_list.size(); i++){
            if(table_uuid == device_discovered_list[i].address){
                // è stato trovato l'oggetto device che ha lo stesso uuid selezionato nella tabella, si può tentare la connessione

                // fermo la scansione
                // m_discovery_agent->stop();

                // creo oggetto dataOut
                dataOut = new dataBridge;
                // creazione del controller per gestire la connessione, da questo punto in poi viene gestito tutto dalla classe MyEMGyro2
                device = new MyEMGyro2(device_discovered_list[i].BLE_device, dataOut);

                // si noti che l'oggetto controller viene creato in ogni caso ovvero anche quando non si è riusciti a stablire una connessione
                // oppure se si è verificato qualche tipo di errore, la responsabilità di distruggere tale oggetto è demandata alla classe MyEMGyro2
                // che esprime queste azioni attraverso segnali che allora il main ascolta

                // connessioni per aggionare stato pulsanti quando si verifica connessione/disconnesione effettiva al device
                connect(device, &MyEMGyro2::deviceConnected, this, &MainWindow::disableScanAndConnection);
                // NOTA: in questa versione appena si verifica disconnessione il main fa in modo tale che tutto l'oggetto MyEMGyro2 creato
                // venga distrutto prima di poter iniziare una qualsiasi altra connessione, la stessa cosa accade se si verifica un errore
                // a livello del controller in MyEMGyro2
                connect(device, &MyEMGyro2::deviceDisconnected, this, &MainWindow::ableScanAndConnection);

                // connessione per tentare connessioni e disconnessioni
                connect(this, &MainWindow::tryConnection, device, &MyEMGyro2::startConnection);
                connect(this, &MainWindow::disconnectionRequest, device, &MyEMGyro2::stopConnection);

                // connessione per ottenere i dati di configurazione della scheda
                connect(dataOut, &dataBridge::decodersSetupData, this, &MainWindow::setupGLscreens);

                // connessione per ricevere stringhe di log
                connect(device, &MyEMGyro2::LogUpdated, this, &MainWindow::updateLog);

                // per impedire che l'utente prema pulsanti o faccia qualsiasi altra cosa disabilito tutta l'interfaccia
                ui->tabs->widget(0)->setEnabled(false);

                // tentiamo la connessione usando il metodo della classe
                emit tryConnection();

                break;
            }
        }

    }else{
        emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") +"]" +
                        "-[SPECIAL INFO]-[tryToConnectToDevice]-[QModelIndexList]-Non è stato selezionato nessun device dalla tabella.");
    }
}
// slot per richiedere disconnessione dal device si attiva quando il pulsante disconnect è premuto
void MainWindow::tryToDisconnectToDevice(){
    // disabilito tutta l'interfaccia per evitare la pressione di pulsanti o qualsiasi altra interazione
    ui->tabs->widget(0)->setEnabled(false);
    emit disconnectionRequest();
    // emit deviceDisconnectionRequest();
}
// sarebbe lo slot usato per applicare i filtri ai device trovati in fase di scansione
void MainWindow::deviceFilter(){
    // rimuovo tutte le voci dalla tabella, applico i filtri alle stringhe che sono nel vettore di array di oggetti device, lo riordino
    // e poi alla fine riscrivo una alla volta le righe della tabella
    // stringa da cercare
    QString str_wanted = ui->search_bar_lineedit->text();
    // nuovo vettore riordinato
    std::vector<device_obj> devices_discovered_list_sorted;

    // richiesta al group dei pulsanti filtro per capire quale tra loro è quello selezionato
    unsigned int filter_type = filter_devices_group->checkedId();
    if(filter_type == 1){
        // filtro per nickname
        for(unsigned int i = 0; i < device_discovered_list.size(); i++){
            // se viene trovata sottostringa nel nickname del device allora questo viene messo in testa al vettore riordinato
            // altrimenti va in coda
            if(!device_discovered_list[i].nickname.contains(str_wanted, Qt::CaseInsensitive))
                devices_discovered_list_sorted.push_back(device_discovered_list[i]);
            else devices_discovered_list_sorted.insert(devices_discovered_list_sorted.begin(), device_discovered_list[i]);
        }
    }else if(filter_type == 0){
        // filtro per name
        for(unsigned int i = 0; i < device_discovered_list.size(); i++){
            // se viene trovata sottostringa nel name del device allora questo viene messo in testa al vettore riordinato
            // altrimenti va in coda
            if(!device_discovered_list[i].name.contains(str_wanted, Qt::CaseInsensitive))
                devices_discovered_list_sorted.push_back(device_discovered_list[i]);
            else devices_discovered_list_sorted.insert(devices_discovered_list_sorted.begin(), device_discovered_list[i]);

            // qDebug() << device_discovered_list[i].BLE_device.address();

        }
    }

    // con il vettore riordinato posso procedere a riscrivere le voci nella tabella, prima le rimuovo tutte
    ui->list_of_discovered_devices_table->setRowCount(0);
    for(unsigned int i = 0; i < devices_discovered_list_sorted.size(); i++){

        // CODICE IDENTICO A QUELLO USATO PER INSERIRE LE RIGHE DI TABELLA DURANTE SCAN

        // get del numro di righe nella tabella e inserimento, l'indice di riga va da 0 a row-1
        int row = ui->list_of_discovered_devices_table->rowCount();
        ui->list_of_discovered_devices_table->insertRow(row);
        // creo gli item per scrivere nella tabella, ogni volta li rendo solo di lettura
        QTableWidgetItem *address_item = new QTableWidgetItem(devices_discovered_list_sorted[i].address);
        address_item ->setFlags(address_item ->flags() & ~Qt::ItemIsEditable);
        QTableWidgetItem *rssi_item = new QTableWidgetItem(QString::number(devices_discovered_list_sorted[i].BLE_device.rssi()));
        rssi_item ->setFlags(rssi_item ->flags() & ~Qt::ItemIsEditable);
        QTableWidgetItem *name_item = new QTableWidgetItem(devices_discovered_list_sorted[i].name);
        name_item ->setFlags(name_item ->flags() & ~Qt::ItemIsEditable);
        QTableWidgetItem *nickname_item = new QTableWidgetItem(devices_discovered_list_sorted[i].nickname);
        nickname_item ->setFlags(nickname_item ->flags() & ~Qt::ItemIsEditable);
        // inserimento effettivo nella tabella, attenzione all'ordine che deve rispettare l'ordine delle colonne
        ui->list_of_discovered_devices_table->setItem(row, 0, address_item );
        ui->list_of_discovered_devices_table->setItem(row, 1, rssi_item );
        ui->list_of_discovered_devices_table->setItem(row, 2, name_item );
        ui->list_of_discovered_devices_table->setItem(row, 3, nickname_item );

    }


}
// slot sato per riscrivere dinamicamente il placeholder della barra di ricerca
void MainWindow::rewritePlaceholder(int id){
    if (id == 0){
        // selezionato il filtraggio per nome
        ui->search_bar_lineedit->setPlaceholderText("Search device by Name");
    }else if(id == 1){
        // selezionato il filtraggio per nickname
        ui->search_bar_lineedit->setPlaceholderText("Search device by Nickname");
    }
}

//##########################

// slot usati da oggetti BLE

// slot usato per aggiungere dispositivi alla tabella, usato dal BLE agent
void MainWindow::deviceDiscovered(const QBluetoothDeviceInfo &device){
    // filtro i dispositivi low energy validi
    if ((device.coreConfigurations() & QBluetoothDeviceInfo::LowEnergyCoreConfiguration)&&(device.isValid())) {

        // qDebug() << "Trovato dispositivo LowEnergy: " << device.name() << device.address().toString();

        // estrazione delle strighe rilevanti per alcune operazioni svolte dall'applicazione, dal filtraggio dei devices fino alla selezione
        // di quello a cui connettersi
        QString address = device.address().toString();
        QString name = device.name();
        QString nickname = "-";

        //effettuo un controllo molto semplice, verifico che lo stesso device non sia stato già inserito nella vettore e quindi
        // messo nella tabella, nel caso termino, NOTA chiaramente è un modo un po brutale, la cosa più corretta sarebbe quantomeno aggiornare il
        // valore di rssi
        for(unsigned i = 0; i < device_discovered_list.size(); i++){
            if(address == device_discovered_list[i].address) return;
        }

        for(unsigned int i = 0; i < favorite_devices.size(); i++){
            if (favorite_devices[i].MAC_address == device.address().toString())
                nickname = favorite_devices[i].nickname;
        }
        // inserimento nel vettore di oggetti device
        device_discovered_list.push_back({device, address, name, nickname});

        // si deve aggiungere il device alla tabella che lo rappresenta come indirizzo nome nickname e rssi, bisogra creare una
        // riga della tabella e compilarla con le informazioni estratte dall'oggetto QBluetoothDeviceInfo

        // get del numro di righe nella tabella e inserimento, l'indice di riga va da 0 a row-1
        int row = ui->list_of_discovered_devices_table->rowCount();
        ui->list_of_discovered_devices_table->insertRow(row);
        // creo gli item per scrivere nella tabella, ogni volta li rendo solo di lettura
        QTableWidgetItem *address_item = new QTableWidgetItem(address);
        address_item ->setFlags(address_item ->flags() & ~Qt::ItemIsEditable);
        QTableWidgetItem *rssi_item = new QTableWidgetItem(QString::number(device.rssi()));
        rssi_item ->setFlags(rssi_item ->flags() & ~Qt::ItemIsEditable);
        QTableWidgetItem *name_item = new QTableWidgetItem(name);
        name_item ->setFlags(name_item ->flags() & ~Qt::ItemIsEditable);
        QTableWidgetItem *nickname_item = new QTableWidgetItem(nickname);
        nickname_item ->setFlags(nickname_item ->flags() & ~Qt::ItemIsEditable);
        // inserimento effettivo nella tabella, attenzione all'ordine che deve rispettare l'ordine delle colonne
        ui->list_of_discovered_devices_table->setItem(row, 0, address_item );
        ui->list_of_discovered_devices_table->setItem(row, 1, rssi_item );
        ui->list_of_discovered_devices_table->setItem(row, 2, name_item );
        ui->list_of_discovered_devices_table->setItem(row, 3, nickname_item );
    }
}
// solt usato per notificare la fine della scansione di device, usato dal BLE agent
void MainWindow::scanFinished(){
    // segnale emesso da discovery agent una volta che la scansione è effettivamente arestata, procedo a riabilitare l'interfaccia gestendo però
    // anche lo stato dei pulsanti
    ui->start_scan_button->setDisabled(false);
    ui->stop_scan_button->setDisabled(true);
    ui->connect_button->setDisabled(false);
    ui->disconnect_button->setDisabled(true);
    // rendo selezionabili le righe della tabella (solo una)
    ui->list_of_discovered_devices_table->setSelectionMode(QAbstractItemView::SingleSelection);
    // rendo premibili i vari pulsanti nel layout per il filtraggio
    ui->filter_button->setDisabled(false);
    ui->search_bar_lineedit->setDisabled(false);
    ui->name_filter_radiobutton->setDisabled(false);
    ui->nickname_filter_radiobutton->setDisabled(false);

    // riabilito tutta l'interfaccia perchè questa è stata disabilitata in stopScan
    ui->tabs->widget(0)->setEnabled(true);
    emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") +"]" +
                    "-[SPECIAL INFO]-[scanFinished]-[QBluetoothDeviceDiscoveryAgent]-Scansione dei device terminata");

    // rimuovo dalla memoria il discovery agent usato per la scansione
    connect(m_discovery_agent, &QObject::destroyed, this, [this](QObject* obj){
        // log per avvisare avvenuta rimozione del device
        emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") +"]" +
                        "-[INFO]-[scanFinished]-[QBluetoothDeviceDiscoveryAgent]-Oggetto usato per la scansione dei device appena terminata distrutto.");
    });
    m_discovery_agent->deleteLater();
}

//##########################

// slot usato per gestire i messaggi di log riguardanti la connessione al device

// in questa versione l'uso del colore è per evidenziare le stringhe in base al valore del campo priority (INFO ERROR ecc)
// [timestamp]-[INFO/ERROR/SPECIALINFO]-[funzione che ha emesso log]-[componente]-messaggio di log
void MainWindow::updateLog(QString s){
    QStringList log_parts = s.split("-");

    // qDebug() << s;
    // definisco il colore in base al valore del campo priority
    QTextCharFormat format;
    QString priority = log_parts[1];
    if(priority == "[INFO]"){
        format.setForeground(Qt::yellow);
    }else if(priority == "[ERROR]"){
        format.setForeground(Qt::red);
    }else if(priority == "[SPECIAL INFO]"){
        format.setForeground(Qt::green);
    }

    QTextCursor cursor = ui->log->textCursor();
    cursor.movePosition(QTextCursor::End);
    // ha senso che questa variabile venga memorizzata solo da quando vengono disabilitati i pulsanti perchè il log ha iniziato ad essere
    //scritto, per prove lo lascio qui
    selected_radiobutton = filter_log_group->checkedId();
    // in base al valore di selected_radiobutton la stringa di log stampata cambia
    switch (selected_radiobutton) {
    case 0:
        // ID 0 è del radio button chiamato nella ui all_radiobutton, questa selezione prevede che tutta la stringa di log venga stapata interamente
        cursor.insertText(log_parts[0] + log_parts[2] + log_parts[3] + log_parts[4] + "\n", format);
        break;

    case 1:
        // ID 1 è del radio button chiamato nella ui normal_radiobutton, questa selezione prevede che della stringa di log si stampino solo certe cose
        cursor.insertText(log_parts[0] + log_parts[4] + "\n", format);
        break;

        // case 2:
        //     // ID 2 è del radio button chiamato nella ui basic_radiobutton, questa selezione prevede che della stringa di log si stampi il minimo
        //     // indispensabile, per evitare di confondere

        //     break;
    }

    // imposto la posizione della scrollbar al massimo cosi che siano visibili i log più recenti
    ui->log->verticalScrollBar()->setValue(ui->log->verticalScrollBar()->maximum());
}




