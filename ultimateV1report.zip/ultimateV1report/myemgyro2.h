#ifndef MYEMGYRO2_H
#define MYEMGYRO2_H

#include <QObject>
#include <QLowEnergyController>
#include <QLowEnergyService>
#include <QLowEnergyCharacteristic>
#include <QBluetoothDeviceInfo>
#include <QDateTime>
#include <QThread>
#include <QByteArray>

// #include "decoder-module/timespec_utils.h"
#include "decoder-module/receiver.h"
#include "decoder-module/out_file.h"
// #include "decoder-module/decoder.h"

// questa classe è specifica per gestire la connessione con un peripherical EMGyro2, l'istanza alla classe va fatta
// dal main solo quando si è certi che si tratta di un device EMGyro2, in caso contrario la classe è progettata per mandare un
// segnale che la classe main gestisce distruggendo immediatamente l'oggetto istanziato

// NOTA: l'istanza alla classe richiede ditruzione esplicita in quanto non è presente nessun parent, tale distruzione deve essere garantita dall'
// oggetto che ha fatto istanza, quindi in questo caso il main windows, in questa versione tale oggetto distrugge sempre l'oggetto ogni volta che si tenta
// una connessione nuova e anche quando si verificano errori di connessione rilevati dalle classi controller e services
class MyEMGyro2: public QObject {
    Q_OBJECT

public:
    explicit MyEMGyro2(const QBluetoothDeviceInfo &info, dataBridge *dataOut);
    ~MyEMGyro2();

    // funzione usata per chiudere la connessione in caso di eventi di errore derivanti dal controller o da uno dei servizi
    void routineForSecureDisconnection();

    // per decodificare dati
    receiver* rec = nullptr;
    dataBridge* bridge = nullptr;
    out_file* out0 = nullptr;


    // metodi per cercare servizi
    void serviceDiscovered(const QBluetoothUuid &newService);
    void serviceScanDone();

    // metodi per gestire cambiamenti dei servizi e delle caratteristiche, ne servono 2 per ogni servizio + 1 se si vogliono ricevere le notifiche
    // void batteryServiceStateChanged(QLowEnergyService::ServiceState s);
    // void batteryCharacteristicChanged(const QLowEnergyCharacteristic &, const QByteArray &);

    void EMGServiceStateChanged(QLowEnergyService::ServiceState s);
    void EMGServiceError(QLowEnergyService::ServiceError e);
    void EMGCharacteristicChanged(const QLowEnergyCharacteristic &c, const QByteArray &v);

    void deviceServiceStateChanged(QLowEnergyService::ServiceState s);
    void deviceServiceError(QLowEnergyService::ServiceError e);
    void deviceCharacteristicChanged(const QLowEnergyCharacteristic &c, const QByteArray &v);

    void GyrServiceStateChanged(QLowEnergyService::ServiceState s);
    void GyrServiceError(QLowEnergyService::ServiceError e);
    void GyrCharacteristicChanged(const QLowEnergyCharacteristic &, const QByteArray &);

    // per ricevere errori dal controller
    void controllerError(QLowEnergyController::Error e);

    // funzione usata internamente per ottenere la stringa di errore in base agli enum di QLowEnergyService::ServiceError
    // per il controller una funzione del genere è inutile perchè è già prevista la funzione errorString() che ritorna diret
    // tamente la stringa di errore
    QString serviceErrorToString(QLowEnergyService::ServiceError e);

signals:
    // segnali per notificare all'interfaccia che la connessione è stata stabilita o interrotta, fondamentali per impostare l'interfaccia
    // in modo tale che non si possano compiere azioni non gestite
    void deviceConnected();
    void deviceDisconnected();
    // void deviceError();

    // segnale per scrivere nel log del main gli errori
    // void errorOccurred(const QString &error);

    // segnale per scrivere notifiche sul log dell'interfaccia
    void LogUpdated(QString s);

public slots:
    // per connessione effettiva al device
    void controllerConnected();
    void controllerDisconnected();

    // slot per gestire il segnale inviato dalla classe principale quando si vuole disconnettere il device
    void stopConnection();
    // slot per gestire il segnale inviato dalla classe principale quando si vuole disconnettere il device
    void startConnection();





private:
    QBluetoothDeviceInfo m_deviceInfo;

    QLowEnergyController *m_controller = nullptr;

    QLowEnergyService *m_batteryService = nullptr;
    QLowEnergyService *m_EMGService = nullptr;
    QLowEnergyService *m_deviceService = nullptr;
    QLowEnergyService *m_GyrService = nullptr;

    // QLowEnergyCharacteristic m_batteryLevelChar;
    // QLowEnergyCharacteristic m_EMGChar;
    // QLowEnergyCharacteristic m_ECGChar;
    // QLowEnergyCharacteristic m_GyrChar;

};










#endif // MYEMGYRO2_H
