#include "device.h"
#include <QDebug>

Device::Device(QObject *parent)
    : QObject(parent)
{}

void Device::connectToDevice(const QBluetoothDeviceInfo &info)
{
    // viene creato il controller
    controller = QLowEnergyController::createCentral(info, this);

    connect(controller, &QLowEnergyController::connected,
            this, &Device::onConnected);
    connect(controller, &QLowEnergyController::disconnected,
            this, &Device::onDisconnected);

    qDebug() << "Connessione al dispositivo..." << info.name();
    controller->connectToDevice();
}

void Device::onConnected()
{
    qDebug() << "Connesso al dispositivo!";
}

void Device::onDisconnected()
{
    qDebug() << "Disconnesso dal dispositivo.";
}
