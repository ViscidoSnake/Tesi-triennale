#ifndef TIMESPEC_UTILS
#define TIMESPEC_UTILS

#include <cstdint>
#include <time.h>

static inline int64_t timespec_diff (struct timespec const *a, struct timespec const *b)
{
        return (a->tv_nsec - b->tv_nsec) + 1000000000 * (int64_t) (a->tv_sec - b->tv_sec);
}

static inline void timespec_add  (struct timespec *a, uint64_t offset)
{
        uint64_t seconds = offset / 1000000000;
        uint64_t nanos   = offset % 1000000000;
        if (a->tv_nsec += nanos > 1000000000) {
                a->tv_nsec -= 1000000000;
                ++seconds;
        }
        a->tv_sec += seconds;
}

#endif
