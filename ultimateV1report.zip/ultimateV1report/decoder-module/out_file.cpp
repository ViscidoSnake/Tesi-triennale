// out_file.cpp:
// Program to dump decoded EMGyro2 data to a file.
// (C) 2020 Giorgio Biagetti


#include "out_file.h"
#include "decoder.h"
#include <iostream>



out_file::out_file (dataBridge* bridge)
    : bridge(bridge) {}

out_file::~out_file(){
    delete bridge;

}


void out_file::operator () (std::string const &type, uint64_t time, unsigned sample, unsigned const *data)
{
    // std::cout << "finalmente il dato decodificato" << std::endl;


    // molto strano, se faccio subito una riconnessione (aspetto poco tempo, meno di quello che serve per far dimenticare il peripherical al PC)
    // allora si verifica un crash credo docuto a bridge, se infatti non lo uso qui allora funziona

    // se però aspetto molto tempo in ogni caso si verifica crash dovuto a index_sorter::operator (delta_idx < 0) throw

    // double EMGtime = static_cast<double>((time - bridge->t0EMG) * 1E-9);
    // bridge->emitEMGsignal({EMGtime,{12,54,54}});
    // double GYRtime = static_cast<double>((time - bridge->t0GYR) * 1E-9);
    // bridge->emitGYRsignal({GYRtime,{12,54,54}});


    // smp data_out;

    if (type == "EMG") {
        // se non ci sono dati salta tutto
        if (!data) return;

        // double timestamp_emg = static_cast<double>((time - bridge->t0EMG) * 1E-9);
        double timestamp_emg = static_cast<double>((time) * 1E-9);


        // if sotto serve per evitare timestamp negativi che si possono verificare inizialmente quando per
        // piccoli problemi di sincronizzazione time è minore di t0EMG, facendo direttamente il return si perdono i campioni
        if(timestamp_emg < 0) return;

        double v[3];
        emg.decode(data, v);


        bridge->emitEMGdataScreen1({timestamp_emg,{v[0]}});
        bridge->emitEMGdataScreen2({timestamp_emg,{v[1]}});
        bridge->emitEMGdataScreen3({timestamp_emg,{v[2]}});

        // switch (emg.channels) {
        // case 1:
        //     bridge->emitEMGdataScreen1({timestamp_emg,{v[0]}});
        //     break;
        // case 2:
        //     bridge->emitEMGdataScreen1({timestamp_emg,{v[0]}});
        //     bridge->emitEMGdataScreen2({timestamp_emg,{v[1]}});
        //     break;
        // case 3:
        //     bridge->emitEMGdataScreen1({timestamp_emg,{v[0]}});
        //     bridge->emitEMGdataScreen2({timestamp_emg,{v[1]}});
        //     bridge->emitEMGdataScreen3({timestamp_emg,{v[2]}});
        //     break;
        // }
    }



    if (type == "GYR") {

        // se non ci sono dati salta tutto
        if(!data) return;

        // double timestamp_gyr = static_cast<double>((time - bridge->t0GYR) * 1E-9);
        double timestamp_gyr = static_cast<double>((time) * 1E-9);

        // if sotto serve per evitare timestamp negativi che si possono verificare inizialmente quando per
        // piccoli problemi di sincronizzazione time è minore di t0EMG, facendo direttamente il return si perdono i campioni
        if(timestamp_gyr < 0) {
            std::cout << "timestamp_gyr: " << timestamp_gyr << std::endl;
            return;
        }

        double v[7];
        gyr.decode(data, v);

        // invio agli schermi
        bridge->emitGYRdataTemp({ timestamp_gyr,{v[0]} });

        bridge->emitGYRdataVel({ timestamp_gyr,{v[1], v[2], v[3]} });

        bridge->emitGYRdataAcc({ timestamp_gyr,{v[4], v[5], v[6]} });


        // smp smp_vel = {timestamp_GYR,{}};
        // for (unsigned i = 1; i <= 3; ++i) {
        //     // dando per scontato che siano i dati di velocità dati come x y e z
        //     smp_vel.val.push_back(v[i]);
        // }

        // std::cout << "GYR data, smp_vel: " << std::endl;
        // std::cout << "smp_vel.tm: " << smp_vel.tm << std::endl;
        // std::cout << "smp_vel.val.size(): " << smp_vel.val.size()<< std::endl;
        // std::cout << "smp_vel.val[0]: " << smp_vel.val[0]<< std::endl;
        // std::cout << "smp_vel.val[1]: " << smp_vel.val[1]<< std::endl;
        // std::cout << "smp_vel.val[2] " << smp_vel.val[2]<< std::endl;

        // smp smp_acc = {timestamp_GYR,{}};
        // for (unsigned i = 4; i <= 6; ++i) {
        //     // dando per scontato che siano i dati di accelerazione dati come x y e z
        //     smp_acc.val.push_back(v[i]);
        // }

        // std::cout << "GYR data, smp_acc: " << std::endl;
        // std::cout << "smp_acc.tm: " << smp_acc.tm << std::endl;
        // std::cout << "smp_acc.val.size(): " << smp_acc.val.size()<< std::endl;
        // std::cout << "smp_acc.val[0]: " << smp_acc.val[0]<< std::endl;
        // std::cout << "smp_acc.val[1]: " << smp_acc.val[1]<< std::endl;
        // std::cout << "smp_acc.val[2] " << smp_acc.val[2]<< std::endl;

        // smp smp_temp = {timestamp_GYR,{v[0]}};

        // std::cout << "GYR data" << std::endl;

        // bridge->emitGYRdataTemp(smp_temp);
        // bridge->emitGYRdataVel(smp_vel);
        // bridge->emitGYRdataAcc(smp_acc);
    }
}




// #include "out_file.h"
// #include "decoder.h"

// out_file::out_file(const std::string &basename, QObject *parent)
//     : QObject(parent)
// {
//     std::string name = basename;
//     if (!name.empty()) name += "-";
//     f_emg = fopen((name + "EMG.txt").c_str(), "w");
//     f_gyr = fopen((name + "GYR.txt").c_str(), "w");
// }

// out_file::~out_file()
// {
//     fclose(f_emg);
//     fclose(f_gyr);
// }

// void out_file::operator()(const std::string &type, uint64_t time, unsigned sample, const unsigned *data)
// {
//     if (type == "EMG") {
//         double v[6];
//         if (data) emg.decode(data, v);
//         // fprintf(f_emg, "%12.9f", time * 1E-9);

//         for (unsigned i = 0; i < emg.channels; ++i) {
//             double val = data ? v[i] : NAN;
//             // fprintf(f_emg, " %+12.9f", val);
//         }
//         // fprintf(f_emg, "\n");

//     }

//     if (type == "GYR") {
//         double v[8];
//         if (data) gyr.decode(data, v);
//         // fprintf(f_gyr, "%12.9f", time * 1E-9);

//         for (unsigned i = 1; i <= 6; ++i) {
//             double val = data ? v[i] : NAN;
//             // fprintf(f_gyr, " %+12.9f", val);
//         }
//         // fprintf(f_gyr, "\n");

//     }
// }

