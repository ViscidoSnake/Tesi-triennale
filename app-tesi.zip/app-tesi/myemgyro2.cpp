#include "myemgyro2.h"

// appena la classe viene creata si crea il controller che tenta la connessione
MyEMGyro2::MyEMGyro2(const QBluetoothDeviceInfo &info, dataBridge *dataOut)
    : bridge(dataOut), m_deviceInfo(info){
    // creo subito l'oggetto controller cioè lo faccio creare e lo punto con il puntatore
    // in fase di istanza parent sarebbe la classe mainWindows tuttavia potrei anche evitare di passarla perchè
    // comunque
    m_controller = QLowEnergyController::createCentral(info, nullptr);

    // creo le connessioni che servono per interagire con il controller
    connect(m_controller, &QLowEnergyController::connected, this, &MyEMGyro2::controllerConnected);
    connect(m_controller, &QLowEnergyController::disconnected, this, &MyEMGyro2::controllerDisconnected);
    connect(m_controller, &QLowEnergyController::errorOccurred, this, &MyEMGyro2::controllerError);

    // creo oggetto per effetuare decodifica e imposto outport
    rec = new receiver(bridge);
    out0 = new out_file(bridge);
    rec->add_port(*out0,0);

    // out_file out0(bridge);
    // rec->add_port(out0);


    // struct timespec ts;
    // clock_gettime(CLOCK_MONOTONIC, &ts);
    // t0 = ts.tv_sec * 1000000000 + ts.tv_nsec / 1;
    // // se metto anche il type nel reciver finisco dentro il terzo if che fa il setup time del sorter Gyr
    // (*rec)(t0);

}

MyEMGyro2::~MyEMGyro2(){
    rec->flush();
    rec->dump();

    // credo sia inutile ma comunque non funziona
    // rec->initialized = true;
    // qDebug() << initialized;
    delete rec;
    delete out0;
    qDebug() << "...fine connessioe...";

    // out0 = nullptr;
    // rec = nullptr;

}

void MyEMGyro2::startConnection(){
    // tentativo di connessione al device, notifico evento, come procede dipende dai segnali che emete la classe controller di qt
    emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") +"]" +
                    "-[SPECIAL INFO]-[startConnection]-[QLowEnergyController]-Richiesta di connessione al device in fase di elaborazione...");
    m_controller->connectToDevice();
}

void MyEMGyro2::stopConnection(){
    // considerando la logica usata dal main e anche quella di questo oggetto, l'operazione di disconnessione è prevista solo quando la connessione
    // al device esiste ovvero quindi se tutti i servizi vengono trovati e nessuno presenta errori dunque in questo punto tutti i servizi esistono
    // e funnzionano come dovrebbero pertanto ha seso disconnetterli
    emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                    "-[SPECIAL INFO]-[stopConnection]-[QLowEnergyController]-Richiesta di disconnessione in fase di elaborazione...");
    routineForSecureDisconnection();
}


// slot per gestione BLE
void MyEMGyro2::controllerConnected(){
    // per qualche strano motivo no si legge il nome del device
    // qDebug() << m_controller->remoteName();

    // emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
    //                 "-[SPECIAL INFO]-[controllerConnected]-[QLowEnergyController]-Device " + m_controller->remoteName() + " connesso.");

    emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                    "-[SPECIAL INFO]-[controllerConnected]-[QLowEnergyController]-Device connesso.");

    // segnale emesso e ricevuto dalla classe principale in modo che l'interfaccia venga impostata in un certo modo
    emit deviceConnected();

    // è possibile procedere con la ricerca dei servizi
    // connessione dei segnali per gestire la ricerca dei servizi
    connect(m_controller, &QLowEnergyController::serviceDiscovered, this, &MyEMGyro2::serviceDiscovered);
    connect(m_controller, &QLowEnergyController::discoveryFinished, this, &MyEMGyro2::serviceScanDone);
    m_controller->discoverServices();
}
// // sarebbe lo slot che viene usato dal main per richiedere la disconnessione del device
// void MyEMGyro2::deviceDisconnectionRequest(){

// }
// ricorda che controllerDisconnected viene eseguito dopo che viene richiesto m_control->disconnectFromDevice()
void MyEMGyro2::controllerDisconnected(){
    // qDebug() << "Device disconnesso!";
    emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                    "-[SPECIAL INFO]-[controllerDisconnected]-[QLowEnergyController]-Device disconnesso.");
    // segnale che il main gestisce in modo tale da ripermettere una scansione e tentativo di riconnessione
    emit deviceDisconnected();
}
// in questa versione se si verificano errori sul controller si procede direttamnte alla disconnessione, questo sotto è
// lo slot di &QLowEnergyController::errorOccurred
void MyEMGyro2::controllerError(QLowEnergyController::Error e){

    // qDebug() << e;
    emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                      "-[ERROR]-[emitDeviceError]-[QLowEnergyController]-Errore grave con il device a cui si sta cercando di connettersi:"
                      + m_controller->errorString());

    routineForSecureDisconnection();

}
// slot usati per ricerca dei servizi
void MyEMGyro2::serviceDiscovered(const QBluetoothUuid &newService){
    // visualizzo i servizzi trovati
    // qDebug() << "nuovo servizio trovato!" << newService.toString();

    // in teria gli UUID dei servizi che poi hanno come caratteristiche i valori delle misure fatte sono:
    // cef92fff-4179-5abe-9ab4-f41a779bd20f EMG
    // 2378621d-74c8-581e-8cd9-a1ac54584ef3 gyro
    // b77f3a36-bfe3-5d75-b732-0402ba0ff0e7 system
    // 0000180f-0000-1000-8000-00805f9b34fb livello batteria

    QString str_service_discovered = newService.toString();

    // ogni volta che trovo uuid dei servizi procedo a creare un oggetto service sul quale inizio a ricercare le caratteristiche che mi servono
    if(str_service_discovered == "{cef92fff-4179-5abe-9ab4-f41a779bd20f}"){
        // gestione servizio EMG
        m_EMGService = m_controller->createServiceObject(newService, this);
        // collegamento dei segnali agli slot per gestire le caratteristiche
        connect(m_EMGService, &QLowEnergyService::stateChanged, this, &MyEMGyro2::EMGServiceStateChanged);
        connect(m_EMGService, &QLowEnergyService::characteristicChanged, this, &MyEMGyro2::EMGCharacteristicChanged);
        // collegamento al segnale errorOccurred a uno slot capace di notificare l'errore e anche gestire la situazione, in
        // questa versione si procede direttamente a chiudere la connessione
        connect(m_EMGService, &QLowEnergyService::errorOccurred, this, &MyEMGyro2::EMGServiceError);

        // qDebug() << "Ricerca delle caratteristiche nel servizio EMG";
        m_EMGService->discoverDetails();

        // emit LogUpdated("R:Servizio EMG esposto dal device.");
        emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                        "-[INFO]-[serviceDiscovered]-[QLowEnergyService]-Servizio EMG esposto dal device.");

    }else if(str_service_discovered == "{b77f3a36-bfe3-5d75-b732-0402ba0ff0e7}"){
        // gestione del servizio che fornisce i dati di telemetria
        m_deviceService = m_controller->createServiceObject(newService, this);
        // collegamento dei segnali agli slot per gestire le caratteristiche
        connect(m_deviceService, &QLowEnergyService::stateChanged, this, &MyEMGyro2::deviceServiceStateChanged);
        connect(m_deviceService, &QLowEnergyService::characteristicChanged, this, &MyEMGyro2::deviceCharacteristicChanged);
        // collegamento al segnale errorOccurred a uno slot capace di notificare l'errore e anche gestire la situazione, in
        // questa versione si procede direttamente a chiudere la connessione
        connect(m_deviceService, &QLowEnergyService::errorOccurred, this, &MyEMGyro2::deviceServiceError);

        // qDebug() << "Ricerca delle caratteristiche nel servizio EMG";
        m_deviceService->discoverDetails();

        // emit LogUpdated("R:Servizio EMG esposto dal device.");
        emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                        "-[INFO]-[serviceDiscovered]-[QLowEnergyService]-Servizio telemetria esposto dal device.");

    }else if(str_service_discovered == "{2378621d-74c8-581e-8cd9-a1ac54584ef3}"){
        // gestione del servizio che fornisce i dati di giroscopi
        m_GyrService = m_controller->createServiceObject(newService, this);
        // collegamento dei segnali agli slot per gestire le caratteristiche
        connect(m_GyrService, &QLowEnergyService::stateChanged, this, &MyEMGyro2::GyrServiceStateChanged);
        connect(m_GyrService, &QLowEnergyService::characteristicChanged, this, &MyEMGyro2::GyrCharacteristicChanged);
        // collegamento al segnale errorOccurred a uno slot capace di notificare l'errore e anche gestire la situazione, in
        // questa versione si procede direttamente a chiudere la connessione
        connect(m_GyrService, &QLowEnergyService::errorOccurred, this, &MyEMGyro2::GyrServiceError);

        // qDebug() << "Ricerca delle caratteristiche nel servizio EMG";
        m_GyrService->discoverDetails();

        // emit LogUpdated("R:Servizio EMG esposto dal device.");
        emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                        "-[INFO]-[serviceDiscovered]-[QLowEnergyService]-Servizio giroscopio esposto dal device.");
    }

    // }else if(str_service_discovered == "{0000180f-0000-1000-8000-00805f9b34fb}"){

    // }
}
void MyEMGyro2::serviceScanDone(){
    // qDebug() << "Ricerca dei servizi terminata";
    emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                    "-[INFO]-[serviceScanDone]-[QLowEnergyService]-Scansione dei servizi terminata.");
    // emit LogUpdated("R:Scansione dei servizi esposti dal device terminata");

    if((m_EMGService == nullptr)&&(m_deviceService == nullptr)&&(m_GyrService == nullptr)){
        // caso in cui non è stato trovato uno dei servizi previsti durante la ricerca
        emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                        "-[ERROR]-[serviceScanDone]-[QLowEnergyService]-La scansione è terminata senza che siano stati trovati i servizi di interesse. Avviata disconnessione al device.");

        routineForSecureDisconnection();
    }

}


// PER GESTIONE SERVIZIO EMG
// per gestire gli errori emessi dal servizio
void MyEMGyro2::EMGServiceError(QLowEnergyService::ServiceError e){

    emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                    "-[ERROR]-[EMGServiceError]-[QLowEnergyService]-Errore grave con il servizio EMG:"
                    + serviceErrorToString(e));
    // viene eseguita la routine di disconnessione forzata
    routineForSecureDisconnection();
}
// per gestire i cambiamenti del servizio
void MyEMGyro2::EMGServiceStateChanged(QLowEnergyService::ServiceState s){
    switch (s) {
    case QLowEnergyService::RemoteServiceDiscovering:{
        // emit LogUpdated("R:Servizio EMG in fase di scoperta...");
        emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                        "-[INFO]-[EMGServiceStateChanged]-[QLowEnergyService]-Servizio EMG in fase di scoperta.");
        // qDebug() << "servizio EMG in fase di scoperta";
        break;
    }
    case QLowEnergyService::RemoteServiceDiscovered:{
        // qDebug() << "servizio EMG scoperto, inizio della ricerca delle caratteristiche";
        emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                        "-[INFO]-[EMGServiceStateChanged]-[QLowEnergyService]-Servizio EMG scoperto, inizio della ricerca delle caratteristiche...");

        // //per scoprire uuid delle caratteristiche
        // const QList<QLowEnergyCharacteristic> chars = m_EMGService->characteristics();
        // for (const auto &c : chars) {
        //     qDebug() << "EMG UUID:" << c.uuid().toString();
        // }

        // sarebbe uuid della caratteristica che contiene le misure EMG, essendo che conosco bene il tipo di caratteristica non
        // ha molto senso applicare controlli sul fatto che esista o se può ricevere notifiche
        const QBluetoothUuid uuidcharacteristic("{cef92ff1-4179-5abe-9ab4-f41a779bd20f}");
        // prendo la caratteristica nel servizio
        const QLowEnergyCharacteristic hrChar = m_EMGService->characteristic(uuidcharacteristic);
        // controllo "simbolico"
        if(hrChar.isValid() == true){

            const QBluetoothUuid uuidcharacteristic2 ("{cef92ff2-4179-5abe-9ab4-f41a779bd20f}");
            const QLowEnergyCharacteristic hrChar2 = m_EMGService->characteristic (uuidcharacteristic2);
            QByteArray acquisition_config;

            // ----------------- SUPPORTED CONFIGURATIONS --------------------
            // 1 - dati EMG campionati a 800Hz , 3 misure ciascuna ottenuta mediante due elettrodi
            // acquisition_config.append(static_cast<char>(0xCC));
            // acquisition_config.append(static_cast<char>(8));
            // acquisition_config.append(static_cast<char>(3));
            // acquisition_config.append(static_cast<char>(012));
            // acquisition_config.append(static_cast<char>(034));
            // acquisition_config.append(static_cast<char>(056));
            // 2 - dati ECG campionati a 200Hz , 3 misure ciascuna ottenuta mediante due elettrodi
            // acquisition_config.append(static_cast<char>(0xCC));
            // acquisition_config.append(static_cast<char>(2));
            // acquisition_config.append(static_cast<char>(3));
            // acquisition_config.append(static_cast<char>(012));
            // acquisition_config.append(static_cast<char>(034));
            // acquisition_config.append(static_cast<char>(056));
            // -------------------------------------------------------------

            // m_EMGService->writeCharacteristic(hrChar2, acquisition_config, QLowEnergyService::WriteWithoutResponse);



            // attivo le notifiche al servizio
            emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                            "-[SPECIAL INFO]-[EMGServiceStateChanged]-[QLowEnergyCharacteristic]-Caratteristica EMG contenente misure trovata, "
                                                                                            "inizio streaming dei dati EMG");
            // emit LogUpdated("R:Caratteristica EMG contenente misure trovata, inizio streaming dei dati EMG");
            QLowEnergyDescriptor m_notificationDesc = hrChar.descriptor(QBluetoothUuid::DescriptorType::ClientCharacteristicConfiguration);
            m_EMGService->writeDescriptor(m_notificationDesc, QLowEnergyCharacteristic::CCCDEnableNotification);

            //----
            struct timespec ts;
            clock_gettime(CLOCK_MONOTONIC, &ts);
            uint64_t timestamp = ts.tv_sec * 1000000000 + ts.tv_nsec / 1;
            //qDebug() << timestamp;
            // se metto anche il type nel reciver finisco dentro il terzo if che fa il setup time del sorter EMG
            bridge->t0EMG=timestamp;
            (*rec)(timestamp,"EMG");

        }else{
            // essendo che passo uuid preciso la caratteristica dovrebbe essere trovata sempre e quindi questo log
            // non verrà mai
            emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                            "-[ERROR]-[EMGServiceStateChanged]-[QLowEnergyCharacteristic]-Caratteristica EMG contenente misure NON trovata");
        }

        break;
    }
    default:
        // con l'aggiunta di EMGServiceError credo che sia inutile scrivere altro in questo punto
        // emit LogUpdated("W:Servizio EMG non disponibile");
        // emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
        //                 "-[ERROR]-[EMGServiceStateChanged]-[QLowEnergyService]-Fallita la scansione del servizio EMG");
        break;
    }
}
// per gestire i cambiamenti della caratteristica
void MyEMGyro2::EMGCharacteristicChanged(const QLowEnergyCharacteristic &c, const QByteArray &v){
    // il modo di leggere il valore dipende da come questo viene impacchettato

    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    uint64_t timestamp = ts.tv_sec * 1000000000 + ts.tv_nsec / 1;

    // FONDAMENTALE: rec vuole che in data non ci siano lettere minuscole!!!!!!!!!!!!!!!!!
    auto const data = (v.toHex()).toUpper().toStdString();
    // qDebug() << data;
    (*rec)(timestamp, "EMG", data);

}


// PER GESTIRE SERVIZIO DEVICE
// per gestire gli errori emessi dal servizio
void MyEMGyro2::deviceServiceError(QLowEnergyService::ServiceError e){

    emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                    "-[ERROR]-[deviceServiceError]-[QLowEnergyService]-Errore grave con il servizio che fornisce dati telemetria:"
                    + serviceErrorToString(e));
    // viene eseguita la routine di disconnessione forzata
    routineForSecureDisconnection();
}
// per gestire i cambiamenti del servizio
void MyEMGyro2::deviceServiceStateChanged(QLowEnergyService::ServiceState s){
    switch (s) {
    case QLowEnergyService::RemoteServiceDiscovering:{
        emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                        "-[INFO]-[deviceServiceStateChanged]-[QLowEnergyService]-Servizio telemetria in fase di scoperta.");
        break;
    }
    case QLowEnergyService::RemoteServiceDiscovered:{
        emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                        "-[INFO]-[deviceServiceStateChanged]-[QLowEnergyService]-Servizio telemetria scoperto, inizio della ricerca "
                                                                                        "delle caratteristiche...");

        // sarebbe uuid della caratteristica che contiene il pacchetto dove dentro sono presenti i vari dati
        // di telemetria, essendo che conosco bene il tipo di caratteristica non
        // ha molto senso applicare controlli sul fatto che esista o se può ricevere notifiche

        // QList<QLowEnergyCharacteristic> a = m_deviceService->characteristics().toList();
        // qDebug() << a[1].uuid().toString();

        const QBluetoothUuid uuidcharacteristic("{b77f3a31-bfe3-5d75-b732-0402ba0ff0e7}");
        // prendo la caratteristica nel servizio
        const QLowEnergyCharacteristic hrChar = m_deviceService->characteristic(uuidcharacteristic);
        // controllo "simbolico"

        if(hrChar.isValid() == true){
            // attivo le notifiche al servizio
            emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                            "-[SPECIAL INFO]-[deviceServiceStateChanged]-[QLowEnergyCharacteristic]-Caratteristica telemetria trovata, "
                            "inizio streaming dei dati di telemetria");

            QLowEnergyDescriptor m_notificationDesc = hrChar.descriptor(QBluetoothUuid::DescriptorType::ClientCharacteristicConfiguration);
            m_deviceService->writeDescriptor(m_notificationDesc, QLowEnergyCharacteristic::CCCDEnableNotification);
        }else{
            // essendo che passo uuid preciso la caratteristica dovrebbe essere trovata sempre e quindi questo log
            // non verrà mai scritto
            emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                            "-[ERROR]-[deviceServiceStateChanged]-[QLowEnergyCharacteristic]-Caratteristica telemetria contenente dati NON trovata");
        }

        break;
    }
    default:
        // con l'aggiunta di EMGServiceError credo che sia inutile scrivere altro in questo punto
        // emit LogUpdated("W:Servizio EMG non disponibile");
        // emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
        //                 "-[ERROR]-[EMGServiceStateChanged]-[QLowEnergyService]-Fallita la scansione del servizio EMG");
        break;
    }
}
// per gestire i cambiamenti della caratteristica
void MyEMGyro2::deviceCharacteristicChanged(const QLowEnergyCharacteristic &c, const QByteArray &v){
    // il modo di leggere il valore dipende da come questo viene impacchettato
    // per ora vuoto essendo che dal servizion non arrivano pacchetti da decodificare
}


// PER GESTIONE SERVIZIO GIROSCOPIO
// per gestire gli errori emessi dal servizio
void MyEMGyro2::GyrServiceError(QLowEnergyService::ServiceError e){

    emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                    "-[ERROR]-[GyrServiceError]-[QLowEnergyService]-Errore grave con il servizio giroscopi:"
                    + serviceErrorToString(e));
    // viene eseguita la routine di disconnessione forzata
    routineForSecureDisconnection();
}
// per gestire i cambiamenti del servizio
void MyEMGyro2::GyrServiceStateChanged(QLowEnergyService::ServiceState s){
    switch (s) {
    case QLowEnergyService::RemoteServiceDiscovering:{
        emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                        "-[INFO]-[GyrServiceStateChanged]-[QLowEnergyService]-Servizio giroscopio in fase di scoperta.");
        break;
    }
    case QLowEnergyService::RemoteServiceDiscovered:{
        emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                        "-[INFO]-[GyrServiceStateChanged]-[QLowEnergyService]-Servizio giroscopio scoperto, inizio della ricerca delle caratteristiche...");

        //per scoprire uuid delle caratteristiche
        // const QList<QLowEnergyCharacteristic> chars = m_GyrService->characteristics();
        // for (const auto &c : chars) {
        //     qDebug() << "EMG UUID:" << c.uuid().toString();
        // }

        // sarebbe uuid della caratteristica che contiene le misure giroscopio, essendo che conosco bene il tipo di caratteristica non
        // ha molto senso applicare controlli sul fatto che esista o se può ricevere notifiche
        const QBluetoothUuid uuidcharacteristic("{23786211-74c8-581e-8cd9-a1ac54584ef3}");
        // prendo la caratteristica nel servizio
        const QLowEnergyCharacteristic hrChar = m_GyrService->characteristic(uuidcharacteristic);
        // controllo "simbolico"
        if(hrChar.isValid() == true){

            // const QBluetoothUuid uuidcharacteristic2 ("{b77f3a32-bfe3-5d75-b732-0402ba0ff0e7}");
            // const QLowEnergyCharacteristic hrChar2 = m_EMGService -> characteristic (uuidcharacteristic2);
            // QByteArray acquisition_config;

            // ----------------- SUPPORTED CONFIGURATIONS --------------------
            // !for now not supported by acquisition device !
            // -------------------------------------------------------------

            // m_GyrService->writeCharacteristic(hrChar2, acquisition_config, QLowEnergyService::WriteWithoutResponse);


            // attivo le notifiche al servizio
            emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                            "-[SPECIAL INFO]-[GyrServiceStateChanged]-[QLowEnergyCharacteristic]-Caratteristica giroscopio contenente misure trovata, "
                            "inizio streaming dei dati giroscopi");
            QLowEnergyDescriptor m_notificationDesc = hrChar.descriptor(QBluetoothUuid::DescriptorType::ClientCharacteristicConfiguration);
            m_GyrService->writeDescriptor(m_notificationDesc, QLowEnergyCharacteristic::CCCDEnableNotification);

            //---- inizializzazione dello stream di dati giroscopio, è necessario passare time attuale al reciver
            // inizializzazione dello stream di dati giroscopio, è necessario passare time attuale al reciver
            // ricordati di rivedere unità di misura del tempo
            struct timespec ts;
            clock_gettime(CLOCK_MONOTONIC, &ts);
            uint64_t timestamp = ts.tv_sec * 1000000000 + ts.tv_nsec / 1;
            // se metto anche il type nel reciver finisco dentro il terzo if che fa il setup time del sorter Gyr
            (*rec)(timestamp,"GYR");
            bridge->t0GYR=timestamp;
            // ----

        }else{
            // essendo che passo uuid preciso la caratteristica dovrebbe essere trovata sempre e quindi questo log
            // non verrà mai
            emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
                            "-[ERROR]-[GyrServiceStateChanged]-[QLowEnergyCharacteristic]-Caratteristica giroscopio contenente misure NON trovata");
        }

        break;
    }
    default:
        // con l'aggiunta di EMGServiceError credo che sia inutile scrivere altro in questo punto
        // emit LogUpdated("W:Servizio EMG non disponibile");
        // emit LogUpdated("[" + QDateTime::currentDateTime().toString("hh:mm:ss") + "]" +
        //                 "-[ERROR]-[EMGServiceStateChanged]-[QLowEnergyService]-Fallita la scansione del servizio EMG");
        break;
    }
}
// per gestire i cambiamenti della caratteristica
void MyEMGyro2::GyrCharacteristicChanged(const QLowEnergyCharacteristic &c, const QByteArray &v){
    // il modo di leggere il valore dipende da come questo viene impacchettato
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    uint64_t timestamp = ts.tv_sec * 1000000000 + ts.tv_nsec / 1;

    // FONDAMENTALE: rec vuole che in data non ci siano lettere minuscole!!!!!!!!!!!!!!!!!
    auto const data = (v.toHex()).toUpper().toStdString();
    (*rec)(timestamp, "GYR", data);

    // per leggere i primi 8 bit (per debug)
    // quint8 firstByte = static_cast<quint8>(v.at(0));
    // qDebug() << "Valore intero:" << static_cast<int>(firstByte);


    // qDebug() << v.toHex().size();



    // emit GyrValUpdated(hrvalue);
}









//---- tools utili

// funzione per convertire in stringa enum che esprime errore emesso dalla classe service
QString MyEMGyro2::serviceErrorToString(QLowEnergyService::ServiceError e) {
    switch (e) {
    case QLowEnergyService::NoError:
        return "NoError";
    case QLowEnergyService::OperationError:
        return "OperationError";
    case QLowEnergyService::CharacteristicReadError:
        return "CharacteristicReadError";
    case QLowEnergyService::CharacteristicWriteError:
        return "CharacteristicWriteError";
    case QLowEnergyService::DescriptorReadError:
        return "DescriptorReadError";
    case QLowEnergyService::DescriptorWriteError:
        return "DescriptorWriteError";
    default:
        return "UnknownError";
    }
}
// funzione usata per chiudere la connessione
void MyEMGyro2::routineForSecureDisconnection(){
    // controllo stato del controller, se diverso da non connesso ha senso forzare la disconnessione
    // qDebug() << m_controller->state();


    // devi disconnettere tutti i servizi ma anche in questo caso hai bisogno di capire se esistono e in che stato si trovano
    // gli eventi di errore della classe QLowEnergyService sono principalmente emessi quando si tentano operazioni di vario genere
    // sulle caratteristiche del servizio, sullo stato del servizio non viene notificat nulla quindi è importante verificare lo stato
    // del servizio e sulla base di questo decidere se è necessaria disconnessione, gli enum che non richiedono disconnessione sono
    // QLowEnergyService::InvalidService e QLowEnergyService::LocalService
    if(m_EMGService != nullptr){
        // non libero la memoria occupata dagli oggetti service perche sono stati creati con il parent che sarebbe l'intero oggetto myGyro2 quindi
        // quando nel main distruggo questo Qt si occupa di rimuovere anche tutti questi altri oggetti, al massimo posso disconnettere ogni oggetto
        // dagli slot che si usano per gestire i segnali di notifica del servizio, in questo modo ignoro qualsiasi altro cambiamento del servizio (anche
        // se in realtà essendo che questo è in uno stato disconnesso non credo che il servizio posso cabiare di stato).
        disconnect(m_EMGService, nullptr, this, nullptr);

    }
    if(m_GyrService != nullptr){
        // non libero la memoria occupata dagli oggetti service perche sono stati creati con il parent che sarebbe l'intero oggetto myGyro2 quindi
        // quando nel main distruggo questo Qt si occupa di rimuovere anche tutti questi altri oggetti, al massimo posso disconnettere ogni oggetto
        // dagli slot che si usano per gestire i segnali di notifica del servizio, in questo modo ignoro qualsiasi altro cambiamento del servizio (anche
        // se in realtà essendo che questo è in uno stato disconnesso non credo che il servizio posso cabiare di stato).
        disconnect(m_GyrService, nullptr, this, nullptr);

    }
    if(m_deviceService != nullptr){
        // non libero la memoria occupata dagli oggetti service perche sono stati creati con il parent che sarebbe l'intero oggetto myGyro2 quindi
        // quando nel main distruggo questo Qt si occupa di rimuovere anche tutti questi altri oggetti, al massimo posso disconnettere ogni oggetto
        // dagli slot che si usano per gestire i segnali di notifica del servizio, in questo modo ignoro qualsiasi altro cambiamento del servizio (anche
        // se in realtà essendo che questo è in uno stato disconnesso non credo che il servizio posso cabiare di stato).
        disconnect(m_deviceService, nullptr, this, nullptr);

    }

    auto m_controller_state = m_controller->state();
    // qDebug() << m_controller_state;
    // i seguenti dovrebbero essere gli stati dove la disconnessione ha senso effetuarla
    if ((m_controller_state == QLowEnergyController::ConnectedState) ||
        (m_controller_state == QLowEnergyController::DiscoveredState) ||
        (m_controller_state == QLowEnergyController::DiscoveringState)) m_controller->disconnectFromDevice();
    else{
        // significa che il controller è in uno stato non connesso quindi non viene eseguito lo slot controllerDisconneted e quindi
        // al main non viene notifica la disconnessione, devo quindi procedere emettendo da qui il segnale al main
        emit deviceDisconnected();
    }

}

//----






