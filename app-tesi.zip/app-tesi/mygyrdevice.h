#ifndef MYGYRDEVICE_H
#define MYGYRDEVICE_H

#include <QObject>

// l'intento è creare una classe molto specifica per interagire con il device EMGyro
class MyGYRDevice
{
public:
    MyGYRDevice();

    // serviziobatteria
    // serviziodati1
    // serviziodati2
    // serviziodati3

// slots:
    // per gestire i cambiamenti del servizio e notifiche delle caratteristiche
    // in teria 2 per ogni servizio quindi 8

// signals:
    // sicuramente per gestire log nell'interfaccia ma anche quelli per mandare i dati
    // segnale che poi la classe openGL manipola

};

#endif // MYGYRDEVICE_H
