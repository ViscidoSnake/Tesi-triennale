#include "mygyrdevice.h"

MyGYRDevice::MyGYRDevice() {}
