// receiver.cpp:
// Program to decode bluetooth streams from the EMGyro2 device.
// (C) 2019-2020 Giorgio Biagetti

#include <iostream>
#include <fstream>
#include <string>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <vector>
#include <deque>
#include <map>

#include "receiver.h"
#include "decoder.h"


uint32_t from_hex (std::string const &s)
{
    uint32_t v = 0;
    for (std::string::size_type i = 0; i < s.size(); ++i) {
        char c = s[i];
        uint8_t d = c >= '0' ? c <= '9' ? c - '0' : c >= 'A' ? c <= 'F' ? c - 'A' + 10 : 0 : 0 : 0;
        v *= 16;
        v += d;
    }
    return v;
}


struct emg_packet
{
	emg_packet () {timestamp = 0; memset(vals, 0xFF, sizeof vals);}
	uint64_t timestamp;
	uint32_t vals[6];
};

struct gyro_packet
{
	gyro_packet () {timestamp = 0;}
	uint64_t timestamp;
	uint32_t type;
	uint32_t vals[7];
};

typedef std::map <uint32_t, uint32_t> subchannel_data; // key: pkt_index, value: data.

std::map <uint8_t, subchannel_data> subchannels;

std::deque  <emg_packet>  emg_pkts(24000); // preallocate 1 minute worth of data
std::deque <gyro_packet> gyro_pkts(6000);  // preallocate 1 minute worth of data

// class to reconstruct the full 32-bit packet index
// from the transmitted least significant 8 bits
// and the associated reception timestamp
class index_sorter
{
public:
	void set_rate (unsigned interval);
	void set_time (uint64_t time);
	unsigned operator () (uint64_t pkt_time, uint8_t  pkt_idx);
	unsigned operator () (uint64_t pkt_time, uint16_t pkt_idx);
	unsigned size  () const {return pkt_counter ? pkt_index + 1 : 0;}
	unsigned count () const {return pkt_counter;}
	static const int bins = 4096 - 6;
	static const int bin_min = -128;
	static const int bin_max = bins + bin_min - 1;
	unsigned stat (int n, bool retran) const {return statistics[retran][n >= bin_min && n <= bin_max ? n - bin_min : 0];}
	uint64_t time () const {return est_interval;}
	uint64_t orig () const {return est_timeorig;}
private:
    uint64_t prev_time = 0;        // timestamp of previously received packet
    uint8_t  prev_idx = 0;         // index of previously received packet

    bool init_time = false;
	uint16_t dummy;
	unsigned pkt_counter  = 0; // number of packets processed
	unsigned pkt_index    = 0; // last reconstructed packet index (unwrapped, 0-based)
	unsigned pkt_interval = 0; // expected  time between packets
	uint64_t est_interval = 0; // estimated time between packets
	uint64_t max_interval = 60000000000;
	uint64_t est_timeorig = 0; // estimated timestamp of packet #0
	unsigned statistics[2][bins] = {0};
};

void index_sorter::set_rate (unsigned interval)
{
	pkt_interval = interval;
	est_interval = interval;
}

void index_sorter::set_time (uint64_t time)
{
	prev_time = time;
	init_time = true;
    std::cout << "passaggio in index_sorter::set_time" << std::endl;

}

unsigned index_sorter::operator () (uint64_t pkt_time, uint8_t pkt_idx)
{
	if (!init_time) {
		prev_time = pkt_time;
		prev_idx = pkt_idx;
		pkt_index = pkt_idx;
		init_time = true;
        //debug
        // std::cout << "cioaojje" << std::endl;
	}



	int      delta_idx  = (int8_t) (uint8_t) (pkt_idx - prev_idx);

    // debug
    // std::cout <<"in idex_sorter ()-delta_idx: "<< delta_idx << std::endl;
    // std::cout <<"in idex_sorter ()-pkt_idx: "<< (int8_t)(pkt_idx) << std::endl;
    // std::cout <<"in idex_sorter ()-prev_idx: "<< (uint8_t)(prev_idx) << std::endl;
    // std::cout <<"in idex_sorter ()-pkt_time "<< pkt_time << std::endl;
    // std::cout <<"in idex_sorter ()-prev_time "<< prev_time << std::endl;


	uint64_t delta_time = pkt_time - prev_time;
	prev_time = pkt_time;
	prev_idx  = pkt_idx;
    // debug
    if (delta_time > max_interval){
        std::cout << "index_sorter::operator - if (delta_time > max_interval) throw" << std::endl;
        std::cout << "index_sorter::operator - pkt_time:" << (uint64_t)pkt_time<< std::endl;
        std::cout << "index_sorter::operator - prev_time:" << (uint64_t)prev_time<< std::endl;
        throw;
    }
    int n = pkt_interval ? (int) ((delta_time + pkt_interval / 2) / pkt_interval) - delta_idx : 0;
	pkt_index += delta_idx += (n + 128) / 256 * 256;
    // debug
    if (delta_idx < 0) {
        std::cout << "index_sorter::operator (delta_idx < 0) throw" << std::endl;
        std::cout <<"in idex_sorter (), delta_idx: "<< delta_idx << std::endl;
        throw;
    }
	++statistics[0][n <= bin_max ? n - bin_min : 0];
	if (!pkt_counter++ && (est_timeorig = pkt_time - pkt_index * pkt_interval) > pkt_time) est_timeorig = 0;
	if (delta_idx == 1) est_interval = (est_interval * 1023 + delta_time) / 1024;

    // std::cout << "debug in index_sorter::operator-pkt_index:" << pkt_index << std::endl;

	return pkt_index;
}

unsigned index_sorter::operator () (uint64_t pkt_time, uint16_t pkt_idx)
{
    const unsigned max_future_retrans = 16; // limit on retransmissions for "future" packets we can handle before considering them wraparounds.
    unsigned i = (pkt_index & 0xFFFF8000) + pkt_idx;

    // std::cout << "da index_sorter::operator - i:" << i << std::endl;

    if (i > pkt_index + max_future_retrans) {
        // debug
        i -= 0x8000;
    }
    if (i > pkt_index + max_future_retrans) {
        //debug
        std::cout << "da index_sorter::operator - pkt_index:" << (uint16_t)pkt_index << std::endl;
        std::cout << "da index_sorter::operator - i:" << i << std::endl;
        std::cout << "da index_sorter::operator - pkt_idx:" << (uint64_t)pkt_idx << std::endl;
        std::cout << "da index_sorter::operator - if (i > pkt_index + max_future_retrans) throw" << std::endl;
        throw;
    }
    int n = pkt_index - i;
    ++statistics[1][n <= bin_max ? n - bin_min : 0];
    // TODO: pkt_index cannot be incremented here because it would make the math in the normal case go astray.
    // but without an increment, long runs of retransmissions do not increase size(), and can even confuse wraparound detector here!
    // so a code like this wont work now: if (i > pkt_index) pkt_index = i;
    // Also check if it is all right to increment pkt_counter!

    // debug
    ++pkt_counter;
    return i;
}


// class to keep track of the drift of the sensor clock:
class reclocker
{
public:
	void set_rate (unsigned interval);
	void set_drift (double new_drift);
	void queue_time (uint64_t time, uint8_t type, unsigned index);
	void update (subchannel_data const &times);
	uint64_t operator () (uint64_t sample_time) const;
	uint64_t last_time () const;
	void dump () const;
private:
	uint64_t pkt_interval = 0;
	uint64_t clk_unwraps  = 0;
	int64_t  rx_delay     = 0;
	uint64_t rx_prevtime  = 0;
	struct pkt_timing
	{
		uint64_t time;
		uint8_t  type;
		unsigned index;
	} timings[256];
	uint8_t head = 0;
	uint8_t tail = 0;
	uint64_t next_clk = 0;
public:
	double drift = 0; // [ppm]
	std::vector < uint64_t > timebase;
	uint64_t const timestep = 1000000000; // subsampling period for timebase
};

FILE *f_pkt = fopen("PKT.txt", "w");
FILE *f_pll = fopen("PLL.txt", "w");

void reclocker::set_rate (unsigned interval)
{
	pkt_interval = interval;
}

void reclocker::set_drift (double new_drift)
{
	drift = new_drift;
}

void reclocker::queue_time (uint64_t time, uint8_t type, unsigned index)
{
	fprintf(f_pkt, "%12.6f %02X %8u\n", time * 1E-9, type, index);
	pkt_timing t = {time, type, index};
	timings[tail++] = t;
	if (tail == head) ++head;
}

void reclocker::update (subchannel_data const &times)
{
    // extract last inserted subchannel data item:
	subchannel_data::const_iterator x = times.end();
	if (x != times.begin()) --x; else return;
	uint32_t index = x->first & 0xFFFFFF00U;
	uint32_t value = x->second;

	// handle timestamp wraparounds:
	if (x != times.begin()) --x;
	if (value < x->second) {
		// wraparound occurred - estimate number of bits:
		uint64_t e = x->second;
		e += pkt_interval / 1000; // TX timestamps are in microseconds
		e -= value;
		int bits = 16 + 31 - __builtin_clz((uint32_t) ((e >> 16) + (e >> 17)));
		clk_unwraps += (uint64_t) 1 << bits;
	}
	uint64_t tx_timestamp = (clk_unwraps + value) * 1000;

	// find index of associated packet:
	uint8_t pos;
	for (pos = head; pos != tail && (timings[pos].type != 1 || timings[pos].index != index); ++pos) ;
	if (pos == tail) return; // if referenced packet was missing, there is little to sync on...

	if ((uint8_t) (pos - head) >= 2) pos -= 2; // normal latency
	uint64_t rx_timestamp = timings[pos].time;
	int64_t delay = rx_timestamp - tx_timestamp;

	if (!rx_delay) {
		rx_delay = delay;
		rx_prevtime = rx_timestamp;
	}

	// if the sample is bad, try to find a better one nearby:
	int64_t delta = delay - rx_delay;
	if (abs(delta) > 3250000) {
		for (int n = -2; n <= 2; ++n) {
			int64_t d = timings[pos + n].time - tx_timestamp - rx_delay;
			if (abs(d) < abs(delta)) {
				delta = d;
				rx_timestamp = timings[pos + n].time;
				delay = rx_timestamp - tx_timestamp;
			}
		}
	}

	bool ok = abs(delta) < 3250000;
	if (ok) { // do not use outliers to update filter
		// filtering (double exponential smoothing):
		const int a = 256;  // offset filter time constant [samples]
		const int b = 8192; // slope  filter time constant [samples]
		const double ka = 1 - 1.0 / a;
		const double kb = 1 - 1.0 / b;
		int64_t old_delay = rx_delay;
		if (int64_t dt = rx_timestamp - rx_prevtime) {
			rx_delay = (rx_delay - drift * 1E-6 * dt) * ka + delay / a;
			drift = drift * kb - double(rx_delay - old_delay) / dt / b * 1E6;
			rx_prevtime = rx_timestamp;
		}
	}



	// build first-order spline for interpolation:
	while (tx_timestamp > next_clk) {
		uint64_t x = (rx_delay + (drift*1e-6) * rx_prevtime + next_clk) / (1 + drift*1e-6);

        //debug
        // std::cout << "sdsdsdsdsdsds" << std::endl;

		timebase.push_back(x);
		next_clk += timestep;
	}

	fprintf(f_pll, "%12.6f %12.6f %12.6f %12.6f %d %lu\n", rx_timestamp * 1E-9, delay * 1E-9, rx_delay * 1E-9, drift, ok, timebase.size());

}

uint64_t reclocker::operator () (uint64_t sample_time) const
{
    if (timebase.empty()) {
        // debug, ATTENZIONE,fa un po casino se è chiamato con l'ltro cout in smoother perche lui è quello più interno, comunque timebase è
        // sempre vuoto, in teoria significa che non viene mai eseguito update di reclocker
        // std::cout << "da dentro reclocker operator-timebase.empty():" << timebase.empty() << std::endl;
        return 0;  // sync not yet possible!
    }
	unsigned i = sample_time / timestep;
	if (i >= timebase.size()) i = timebase.size() - 1;
	uint64_t k = sample_time - timestep * i;
	uint64_t x = timebase[i];
	int64_t  d = i + 1 < timebase.size() ? timebase[i + 1] - x : timestep / (1 + drift*1e-6);
	int64_t  c = ((__int128) d * k + timestep / 2) / timestep;
	return x + c;
}

uint64_t reclocker::last_time () const
{
	uint8_t p = tail;
	return timings[--p].time;
}

void reclocker::dump () const
{
	FILE *f = fopen("CLK.txt", "w");
	for (uint64_t t = 0; t < timebase.size(); ++t)
		fprintf(f, "%.9f %.9f\n", t*timestep*1e-9, timebase[t] * 1e-9);
	fclose(f);
}

class sample_reclocker
{
public:
	void update (subchannel_data const &times);
	uint64_t pkt_interval = 0;
	uint64_t clk_unwraps  = 0;
	std::map <unsigned, uint64_t> timebase;
};

void sample_reclocker::update (subchannel_data const &times)
{
	// extract last inserted subchannel data item:
	subchannel_data::const_iterator x = times.end();
	if (x != times.begin()) --x; else return;

	unsigned index = x->first;
	uint32_t value = x->second;

	// handle timestamp wraparounds:
	if (x != times.begin()) --x;
	if (value < x->second) {
		// wraparound occurred - estimate number of bits:
		uint64_t e = x->second;
		e += pkt_interval / 1000; // TX timestamps are in microseconds
		e -= value;
		int bits = 16 + 31 - __builtin_clz((uint32_t) ((e >> 16) + (e >> 17)));
		clk_unwraps += (uint64_t) 1 << bits;
	}
	uint64_t timestamp = (clk_unwraps + value) * 1000;

	timebase[index] = timestamp;
}


index_sorter emg_sorter;
index_sorter gyr_sorter;
index_sorter *sorters[4] = {0, &emg_sorter, &gyr_sorter, 0};

reclocker clk;
sample_reclocker clk2;


// class to smooth clock drifts with gaussian FIR filter:
class smoother
{
public:
	smoother (unsigned lookahead);
	uint64_t operator () (uint64_t sample_time);
private: // methods
	void fit (int i);
private: // data
	const unsigned lookahead;
	const unsigned oversample;
	unsigned last_index = 0;
	unsigned last_delay = 0;
	std::vector <double> h; // filter impulse response (must be 0 at extremes)
	std::vector <double> y; // oversampled filter output on a single interval
};

#define _USE_MATH_DEFINES
#include <cmath>
smoother::smoother (unsigned lookahead) : lookahead(lookahead), oversample(100)
{
    if (!lookahead) return;
    const int o = oversample * lookahead;
    h.resize(2 * o + 1);
    y.resize(oversample + 1);
    const int smooth = oversample / 4; // length of raised cosine roll-off at window boundaries
    double gain = 0;
    for (int n = -o; n <= o; ++n) {
        double x = 4.0 * n / o;
        double y = exp(-(x * x));
        if (o + n < smooth) y *= (1 - cos(M_PI * (o + n) / smooth)) / 2;
        if (o - n < smooth) y *= (1 - cos(M_PI * (o - n) / smooth)) / 2;
        h[n + o] = y;
        if (n == 0) gain *= 2;
        if (n <= 0) gain += y;
    }
    gain = oversample / gain;
    for (auto &x : h) x *= gain;
}

void smoother::fit (int i)
{
    last_index = i;
    last_delay = clk.timebase.size();
    int last = last_delay - 1;
    int64_t driftstep = clk.timestep / (1 + clk.drift * 1E-6);
    int64_t basetime  = i > last ? int64_t(clk.timebase[last]) + (i - last) * driftstep : int64_t(clk.timebase[i]);
    for (unsigned t = 0; t <= oversample; y[t++] = 0) ;
    for (int k = 0, n = i - int(lookahead); n <= i + int(lookahead); ++n, k += oversample) {
        double v =
            n < 0 ? n * driftstep + int64_t(clk.timebase[0]) :
                n > last ? int64_t(clk.timebase[last]) + (n - last) * driftstep
                         : int64_t(clk.timebase[n]);
        v -= basetime + (n - i) * driftstep;
        for (int t = 0; t <= oversample; ++t) {
            int j = k - t;
            if (j >= 0) y[t] += h[j] * v;
        }
    }
    for (unsigned t = 0; t <= oversample; ++t)
        y[t] += basetime + double(t) / oversample * driftstep;
}

uint64_t smoother::operator () (uint64_t sample_time)
{
    //debug, ATTENZIONE, in teoria finisco sempre dentro if che segue perche comunque lookahead è sempre 0 essendo inizializzato lo smoother
    // a 0 (lateza nulla) quindi forse il problema è clk operator ---> SOLUZIONE: clk fa update e quindi estende timebase SOLO se ce anche
    // il pacchetto EMG da processare!!!!
    // std::cout << "da dentro smoother operator-clk.timebase.empty():" << clk.timebase.empty() << std::endl;
    // std::cout << "da dentro smoother operator-lookahead:" << lookahead << std::endl;

    if (clk.timebase.empty() || !lookahead){
        //debug
        // std::cout << "da dentro smoother operator-clk(sample_time):" << clk(sample_time) << std::endl;
        return clk(sample_time); // filtering not possible... guess something!
    }

    unsigned i = sample_time / clk.timestep;
    if (i != last_index || !i && last_delay != clk.timebase.size())
        fit(i);

    uint64_t k = sample_time - clk.timestep * i;
    unsigned j = k * oversample / clk.timestep;
    double x = double(k * oversample - j * clk.timestep) / clk.timestep;

    double r = y[j] * (1 - x) + y[j + 1] * x;

    //debug
    // std::cout << "ssdsds" << std::endl;

    return r;
}

// Implementation of class receiver:


unsigned max_emg_len = 0;
uint64_t max_latency = 0;

uint32_t sub_data;
uint8_t  sub_mask;
uint32_t sub_chno = 0xFF;

struct dispatch
{
	outport *port;
	uint64_t latency;
	smoother spline[2];
	unsigned last_index[4]; // one for each pkt_typr
};

std::vector<dispatch> ports;

bool initialized= false;
// real-time statistics:
unsigned recv_ontime= 0;
unsigned recv_delayed= 0;
unsigned last_ontime= 0;
unsigned last_delayed = 0;
uint64_t last_timestamp = 0;


receiver::receiver (dataBridge* bridge) : bridge(bridge)
{
    decodersInizialized = false;
    // debug
    if (initialized) {
        std::cout << "da receiver::receiver - if (initialized) throw" << std::endl;
        std::cout << "da receiver::receiver - initialized: "<< initialized << std::endl;
        throw;
    } // only one instance allowed!
    initialized = true;
    // debug
    std::cout << "da receiver::receiver, last_timestamp: " << (uint64_t)last_timestamp << std::endl;

}

// debug
// distruttore di receiver, imposta valori delle variabili globali
receiver::~receiver(){

    initialized = false;
    recv_ontime = 0;
    recv_delayed = 0;
    last_ontime = 0;
    last_delayed = 0;
    last_timestamp = 0;

    max_emg_len = 0;
    max_latency = 0;

    // sub_data;
    // sub_mask;
    sub_chno = 0xFF;
}

void receiver::setup (double drift)
{
	clk.set_drift(drift);
}

void receiver::operator () (uint64_t time, std::string const &type, std::string const &data)
{

    // std::cout << "receiver::operator chiamata"<< std::endl;


	uint8_t pkt_type = 0;
	if (type == "EMG") pkt_type = 1;
	if (type == "GYR") pkt_type = 2;

    // debug
    // std::cout << "data:" << data << std::endl;

	// an empty data packet with a specified type is used to set the stream starting time:
	if (sorters[pkt_type] && data.empty()) {

        // debug
        std::cout << "finisco in sorters[pkt_type] && data.empty()"<< std::endl;

        // std::cout << "if 3 di reciver eseguito" << data << std::endl;
        sorters[pkt_type]->set_time(time);


		return;
	}

	// extract packet index if known format:
	unsigned index = 0;
    uint8_t pkt_idx = 0;
	if (pkt_type) {
        if (data.size() < 2) return;
        // debug, ATTENZIONE, a pkt_idx viene assegnato valore 0 dopo circa 11 pacchetti, sembra come se gli 8 bit
        // in testa al pacchetto non cambiassero in modo ordinato, credo sia qualcosa di simile al caso
        // di perdita di pacchetti solo che con questo comportamente se ne perdono circa 245 e il receiver lancia
        // un errore (delta_idx negativo) ------> RISOLTO, il problema era che nel data erano presenti caratteri minuscoli!
        pkt_idx = from_hex(data.substr(0, 2));
        // debug
        // std::cout << "data:" << data << std::endl;
        // std::cout << "pkt_idx:" << static_cast<int>(pkt_idx)<< std::endl;
        // std::cout << "......." << std::endl;


	}

    // std::cout << "debug1" << std::endl;

	// process subchannel data and retransmissions:
	switch (pkt_type) {
		case 1: { // EMG
			max_emg_len = (data.size() - 2) / 6;
			bool extra = data.size() == max_emg_len * 6 + 4;
			if (extra && (pkt_idx & 0x80)) {
				// this is a retransmission:
				++recv_delayed;
				pkt_type |= 0x80;
				uint16_t ext_idx = (from_hex(data.substr(max_emg_len * 6 + 2, 2)) << 7) + (pkt_idx & 0x7F);
				index = emg_sorter(time, ext_idx);
			} else {
				// this is a timely-received packet:
				++recv_ontime;
				index = emg_sorter(time, pkt_idx);
				if (extra) {
					uint8_t byte = from_hex(data.substr(max_emg_len * 6 + 2, 2));
					uint8_t chno = (pkt_idx & 0xFF) >> 2;
					uint8_t cpos = (pkt_idx & 0x03);
					unsigned ihi = index & 0xFFFFFFFCU;
					if (ihi != sub_chno) {
						sub_data = 0;
						sub_mask = 0;
						sub_chno = ihi;
					}
					sub_data |= byte << (8 * cpos);
					sub_mask |= 1 << cpos;
					if (sub_mask == 0x0F) {
						subchannels[chno][ihi] = sub_data;
                        if (chno == 0) emg.setup(sub_data);
						if (chno == 4) clk.update(subchannels[4]);
					} else if (chno == 0 && cpos == 0) {
						// mode byte in subchannel 0 needs early processing,
						// it contains metainformation needed to decode data!
						if (emg.setup(sub_data)) {
							unsigned interval = 1000000000 / emg.datarate * (max_emg_len / emg.channels);
							emg_sorter.set_rate(interval);
							clk.set_rate(interval);
						}
					}
				}
			}
			// print statistcs:
            // debug
            // std::cout << "last_timestamp:" << last_timestamp << std::endl;

			if (time > last_timestamp + 2000000000) {
				unsigned new_ontime = recv_ontime - last_ontime;
				unsigned new_delayed = recv_delayed - last_delayed;
				last_ontime = recv_ontime;
				last_delayed = recv_delayed;
				last_timestamp = time;
				printf("%13.9f T:%6u D:%6u L:%6u  RETRAN: %4.1f%%\n", time * 1e-9, recv_ontime, recv_delayed, emg_sorter.size() - emg_sorter.count(), double(new_delayed)/(new_ontime + new_delayed)*100);
			}
		} break;
		case 2: { // GYR

            if (data.size() < 32) return;
			bool extra = data.size() > 32;
			if (extra && (pkt_idx & 0x01)) {
				// this is a retransmission:
				pkt_type |= 0x80;
				uint16_t ext_idx = (from_hex(data.substr(32, 2)) << 7) + (pkt_idx >> 1);
                index = gyr_sorter(time, ext_idx);
			} else {
                // std::cout << "debug3" << std::endl;

				// this is a timely-received packet:
				index = gyr_sorter(time, pkt_idx);

                // std::cout << "debug4: index:" << index << std::endl;

				uint8_t chno = pkt_idx & 0x0F;
				uint32_t sub = 0;

                for (unsigned i = 32; i < data.size(); i += 2){
                    sub |= from_hex(data.substr(i, 2)) << (i - 32) / 2 * 8;
                }

                // std::cout << "debug5" << std::endl;

				subchannels[chno + 0x80][index] = sub;


				if (chno == 0 && data.size() == 34) {
					if (gyr.setup(sub)) {
						gyr_sorter.set_rate(gyr.interval);
						clk2.pkt_interval = gyr.interval;
					}
				}
                //debug
                // std::cout << "pkt_idx:" << (uint8_t)pkt_idx<< std::endl;
                if (chno == 2){
                    clk2.update(subchannels[chno + 0x80]);
                }
			}
		} break;
	}


	// update PLL:
	if (!type.empty())
		clk.queue_time(time, pkt_type, index);

	// decode packets:
	switch (pkt_type & 0x7F) {
		case 1: { // EMG
			// grow storage space if needed:
			while (index >= emg_pkts.size()) emg_pkts.resize(2 * emg_pkts.size());
			emg_packet &p = emg_pkts[index];
			p.timestamp = time;
			for (unsigned i = 0; i < 6 && i < max_emg_len; ++i)
				p.vals[i] = from_hex(data.substr(2 + i * 6, 6));
		} break;
		case 2: { // GYR

			// grow storage space if needed:
			while (index >= gyro_pkts.size()) gyro_pkts.resize(2 * gyro_pkts.size());
			gyro_packet &p = gyro_pkts[index];
			p.timestamp = time;
			p.type = from_hex(data.substr(2, 2));
			for (unsigned i = 0; i < 7; ++i)
				p.vals[i] = from_hex(data.substr(4 + i * 4, 2)) + 256 * from_hex(data.substr(6 + i * 4, 2));
		} break;
	}


//	fprintf(stdout, "%.9f %lu\n", time*1e-9, clk.timebase.size());
	// dispatch to attached output ports:
	for (auto &x : ports) {
		// process EMG backlog:
		[&] {
			for (unsigned &last_index = x.last_index[1]; last_index < emg_sorter.size(); ++last_index) {
				if (subchannels[2].empty()) return;
				unsigned samples = max_emg_len / emg.channels;
				unsigned sample  = last_index * (max_emg_len / emg.channels);
				uint64_t tsample = 1000000000 / emg.datarate;
				uint64_t toffset = subchannels[2].begin()->second * uint64_t(1000);
				emg_packet &p = emg_pkts[last_index];
				for (unsigned i = 0; i < samples; ++i, ++sample) {
					uint64_t t = x.spline[0](sample * tsample + toffset);
					if (!i && (!t || t + x.latency > time)) return;
					if (!p.timestamp)
						// fill missing packets with NaNs:
						(*x.port)("EMG", t, sample);
					else
						(*x.port)("EMG", t, sample, p.vals + i * emg.channels);
				}
			}
		}();
		// process GYR backlog:
		[&] {
			for (unsigned &last_index = x.last_index[2]; last_index < gyr_sorter.size(); ++last_index) {
				auto const &times = clk2.timebase;

                if (!gyr.interval || times.empty()) return;
				auto p2 = times.upper_bound(last_index);
				auto p1 = p2;
				if (p1 != times.begin())
					--p1;
				else
					p2 = times.end();
				unsigned i1 = p1->first;
				uint64_t v1 = p1->second;
				uint64_t t = x.spline[1]([&] {
					if (p2 == times.end()) {
						// only one time sample available...

						return v1 + int(last_index - i1) * int64_t(gyr_sorter.time());
					} else {
						unsigned i2 = p2->first;
						uint64_t v2 = p2->second;
                        return v1 + (last_index - i1) * (v2 - v1) / (i2 - i1);
					}
				}());
                // debug
                // std::cout << "t:" << static_cast<int>(t) <<std::endl;
                // std::cout << "x.latency:" << static_cast<int>(x.latency) <<std::endl;
                // std::cout << "time:" << static_cast<int>(time) <<std::endl;


                if (!t || t + x.latency > time) return;
				gyro_packet &p = gyro_pkts[last_index];
				if (!p.timestamp)
					// fill missing packets with NaNs:
					(*x.port)("GYR", t, last_index);
				else
					(*x.port)("GYR", t, last_index, p.vals);
			}
		}();
	}

    //ATTENZIONE DA TESTARE SE FUNZIONA BENE: mi metto in fondo per un motivo di semplicità questo può portare a perdita di dati
    // nei primi istanti in cui la connessione è stabilita poichè magari una caratteristica è stata rilevata in ritardo rispetto all'altra.
    // il controllo si basa sul verificare che i vit di config risultino diversi a quelli assegnati in fase di istanza, la variabile
    // decodersInitialized viene usata per evitare di iviare più di una volta le informazioni di configurazione
    if (!decodersInizialized && (gyr.config != 0x100) && (emg.config != 0xC0)){
        bridge->emitDecodersSetupData({emg.config, emg.channels, emg.datarate, 1E9/gyr.interval, gyr.gyr_range, gyr.acc_range});
        decodersInizialized = true;
    }

}

void receiver::add_port (outport &port, uint64_t latency)
{
	if (latency > max_latency) max_latency = latency;
	unsigned n = latency / clk.timestep;
	if (n < 5)
		n = 0; // Gaussian filter does not work with low latencies
	else
		--n;   // Last point is usually not available due to subchannel delay
	ports.push_back(dispatch{&port, latency, {n, n}});
}

void receiver::flush ()
{
	(*this)(clk.last_time() + max_latency + 1000000000);
    //debug
    initialized = false;

}

void receiver::dump ()
{

	clk.dump();

	// remove extra unused elements:
	emg_pkts.resize(emg_sorter.size());
	gyro_pkts.resize(gyr_sorter.size());

	FILE *f;

	f = fopen("stats-EMG.txt", "w");
	for (int i = emg_sorter.bin_min; i <= emg_sorter.bin_max; ++i)
		fprintf(f, "%d %d %d\n", i, emg_sorter.stat(i, false), emg_sorter.stat(i, true));
	fclose(f);
	fprintf(stderr, "EMG time: %lu\n", emg_sorter.time());
	f = fopen("stats-GYR.txt", "w");
	for (int i = gyr_sorter.bin_min; i <= gyr_sorter.bin_max; ++i)
		fprintf(f, "%d %d %d\n", i, gyr_sorter.stat(i, false), gyr_sorter.stat(i, true));
	fclose(f);
	fprintf(stderr, "GYR time: %lu\n", gyr_sorter.time());

	// align time:
	uint32_t old = 0, wraps = 0;
	uint64_t tx_timestamp = 0;
	f = fopen("TIME2.txt", "w");
	for (auto x : subchannels[2]) {
		uint32_t index = x.first & 0xFFFFFF00U;
		if (x.second < old) ++wraps;
		old = x.second;
		fprintf(f, "%12.6f %12.6f %d\n", emg_pkts[index].timestamp * 1E-9, ((uint64_t) (1 << 24) * wraps + x.second) * 1E-6, index);
	}
	fclose(f);

	f = fopen("TIME4.txt", "w");
	old = 0;
	wraps = 0;
	for (auto x : subchannels[4]) {
		uint32_t index = x.first & 0xFFFFFF00U;
		if (x.second < old) ++wraps;
		old = x.second;
		fprintf(f, "%12.6f %12.6f %d\n", emg_pkts[index].timestamp * 1E-9, ((uint64_t) (1 << 24) * wraps + x.second) * 1E-6, index);
	}
	fclose(f);


	f = fopen("TIMEG2.txt", "w");
	old = 0;
	wraps = 0;
	for (auto x : subchannels[0x82]) {
		uint32_t index = x.first;
		if (x.second < old) ++wraps;
		old = x.second;
		tx_timestamp = (uint64_t) (1 << 24) * wraps + x.second;
		fprintf(f, "%12.6f %12.6f %d\n", gyro_pkts[index].timestamp * 1E-9, tx_timestamp * 1E-6, index);
	}
	fclose(f);

}

