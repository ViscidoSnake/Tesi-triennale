// btread.cpp:
// Program to parse bluetooth stream dumps from the EMGyro2 device.
// (C) 2019-2020 Giorgio Biagetti

#include <iostream>
#include <fstream>
#include <string>

#include "timespec_utils.h"
#include "receiver.h"
#include "out_file.h"
#include "decoder.h"

// Converts a string with a timestamp in the fixed format YYYY-MM-DD HH:MM:SS.xxx[xxx[xxx]]
// to a struct timespec. There must be exactly 3, 6, or 9 digits after the decimal point.
// Time is interpreted as local time unless the utc flag is set to true.
// No leading or trailing spaces are allowed.
struct timespec parse_time (std::string const &s, bool utc = false)
{
	const char *p = s.c_str();
	struct tm t;
	t.tm_sec  = atoi(p + 17);
	t.tm_min  = atoi(p + 14);
	t.tm_hour = atoi(p + 11);
	t.tm_mday = atoi(p + 8);
	t.tm_mon  = atoi(p + 5) - 1;
	t.tm_year = atoi(p + 0) - 1900;
	t.tm_wday  = 0; // not known
	t.tm_yday  = 0; // not known
	t.tm_isdst = 0; // not known
	struct timespec ts;
	ts.tv_sec = utc ? timegm(&t) : mktime(&t);
	ts.tv_nsec = atoi(p + 20) * (s.size() == 23 ? 1000000 : s.size() == 26 ? 1000 : s.size() == 29 ? 1 : 0);
	return ts;
}

#include <random>
std::random_device rd;
std::mt19937 gen(1);
std::bernoulli_distribution randomgen(0.05);

receiver rec;

int main (int argc, char *argv[])
{
	if (argc < 2) {
		std::cerr << "Usage: " << argv[0] << " <filename>" << std::endl;
		return 1;
	}

	std::ifstream in(argv[1]);
	if (!in.is_open()) {
		std::cerr << "Unable to open input file." << std::endl;
		return 1;
	}

	// for old dumps that do not contain subchannel 0 configuration data:
	if (argc > 2) emg.datarate = atoi(argv[2]);
	if (argc > 3) emg.channels = atoi(argv[3]);

	out_file out0("RT");
	out_file out1("2s");
	out_file out2("10s");
	out_file out3("60s");
	rec.add_port(out0);
	rec.add_port(out1,  2000000000);
	rec.add_port(out2, 10000000000);
	rec.add_port(out3, 60000000000);

	FILE *f = fopen("TMR.txt", "w");

	uint64_t last_time = 0;
	struct timespec t0 = {0,0};          // time (absolute) of connect event
	for (std::string line; std::getline(in, line); ) {
		if (line.size() < 29) continue;
		char type = line[27];
		std::string data = line.substr(29);

		struct timespec ts = parse_time(line.substr(0, 26));
		if (type == '*' && data.substr(0, 13) == "CONNECTING TO") {
			// extract MAC address:
			std::string const &bt_address = data.substr(15, 17);
			std::cerr << "MAC address: " << bt_address << std::endl;
			std::ifstream driftfile((bt_address + "-drift.txt").c_str());
			if (driftfile.is_open()) {
				double drift;
				driftfile >> drift;
				rec.setup(drift);
			}
		}
		if (type == '*' && data == "CONNECT") {
			t0 = ts;
			continue;
		} else if (!t0.tv_sec) continue;
		uint64_t time = timespec_diff(&ts, &t0);

		if (type == '*' && data == "TIMER START")
			fprintf(f, "%12.6f", time * 1E-9);
		if (type == '*' && data == "TIMER STOP")
			fprintf(f, "\t%12.6f\n", time * 1E-9);

		std::string channel;
		if (type == '>' || type == '<') {
			channel = data.substr(0, 3);
			data = data.substr(4);
			if (type == '>') {
				uint32_t from_hex (std::string const &s);
//				printf("%12.6f %u\n", time * 1e-9, from_hex(data.substr(0,2)));
//				continue;
				// simulate periodic timeout interrupts if no packets are received for some time:
				while ((last_time += 10000000) < time) rec(last_time);
				// simulate RX-side packet loss by randomly discarding packets:
				// if (randomgen(gen)) continue;
				rec(last_time = time, channel, data);
			} else if (type == '<' && data == "ENABLE") {
				rec(last_time = time, channel);
			}

		}
	}

	fclose(f);

	rec.flush();

	rec.dump();

	// convert measured current if present:
	std::ifstream currentfile("current.txt");
	if (!currentfile.is_open()) return 0;
	f = fopen("INA.txt", "w");
	double t_offset = 0;
	for (std::string line; std::getline(currentfile, line); ) {
		if (!line.size()) continue;
		if (line.substr(0, 5) == "# UTC") {
			struct timespec t_ina = parse_time(line.substr(6), true);
			t_offset = timespec_diff(&t_ina, &t0) * 1E-9;
		}
		if (line[0] == '@') {
			double t  = atof(line.substr(1,14).c_str());
			double vb = atof(line.substr(23,8).c_str());
			double is = atof(line.substr(42,8).c_str());
			double rs = atof(line.substr(61,4).c_str());
			fprintf(f, "%12.6f %+8.*f\n", t + t_offset, rs < 20 ? rs < 2 ? rs < 0.2 ? 3 : 4 : 5 : 2, is / rs / 1E3);
		}
	}
	fclose(f);

	return 0;
}

