#ifndef DATABRIDGE_H
#define DATABRIDGE_H

#include <QObject>
#include <QDebug>

typedef struct{
    double tm;
    std::vector<double> val;
}smp;

typedef struct{
    // per EMG
    unsigned config;
    int channels;
    int datarateEMG;
    // per GYR
    double  datarateGYR;
    int  gyr_range;
    int  acc_range;
}decoders_setup_data;

// classe usata per mandare i dati verso un oggetto che sia capace di riceverli quindi deve avere degli slot appositi
class dataBridge : public QObject
{
    Q_OBJECT
public:
    explicit dataBridge(QObject *parent = nullptr);
    ~dataBridge();

    uint64_t t0EMG = 0;
    uint64_t t0GYR = 0;

    // metodi e variabili per far uscire i dati acquisiti dalla scheda dall'oggetto out_file
    void emitGYRdataTemp(smp data);
    void emitGYRdataVel(smp data);
    void emitGYRdataAcc(smp data);
    void emitEMGdataScreen1(smp data);
    void emitEMGdataScreen2(smp data);
    void emitEMGdataScreen3(smp data);

    // metodi e variabili per far uscire i dati estratti dagli oggetti decoder durante la fase di setup
    void emitDecodersSetupData(decoders_setup_data data);

signals:
    // metodi e variabili per far uscire i dati acquisiti dalla scheda dall'oggetto out_file
    void GYRdataTemp(smp data);
    void GYRdataVel(smp data);
    void GYRdataAcc(smp data);
    void EMGdataScreen1(smp data);
    void EMGdataScreen2(smp data);
    void EMGdataScreen3(smp data);

    // segnale per emettere i dati di setup dei decoder
    void decodersSetupData(decoders_setup_data data);


};

#endif // DATABRIDGE_H
