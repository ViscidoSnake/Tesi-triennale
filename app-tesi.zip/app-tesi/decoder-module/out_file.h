// out_file.h:
// Program to dump decoded EMGyro2 data to a file.
// (C) 2020 Giorgio Biagetti

#ifndef OUTFILE_H
#define OUTFILE_H

#include "receiver.h"
// #include "databridge.h"

#include <cstdio>

class out_file : public outport
{
public:
    out_file (dataBridge* bridge);
    void operator () (std::string const &type, uint64_t time, unsigned sample, unsigned const *data = 0);
    virtual ~out_file();
    // variabile ponte per far uscire i dati
    dataBridge* bridge;
private:

};

#endif



// #ifndef OUT_FILE_H
// #define OUT_FILE_H

// #include <QObject>
// #include <string>

// class out_file : public QObject
// {
//     Q_OBJECT

// public:
//     explicit out_file(const std::string &basename, QObject *parent = nullptr);
//     ~out_file();

//     void operator()(const std::string &type, uint64_t time, unsigned sample, const unsigned *data);

// signals:
//     void newEmgSample(double time, const std::vector<double> &values);
//     void newGyrSample(double time, const std::vector<double> &values);

// private:
//     FILE *f_emg;
//     FILE *f_gyr;
// };

// #endif
