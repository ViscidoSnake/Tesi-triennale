
#ifndef MYGLWIDGET_H
#define MYGLWIDGET_H

#define RED {1.0f, 0.0f, 0.0f, 1.0f}
#define GREEN {0.0f, 1.0f, 0.0f, 1.0f}
#define BLUE {0.0f, 0.0f, 1.0f, 1.0f}
#define YELLOW {1.0f, 1.0f, 0.0f, 1.0f}
#define ORANGE {1.0f, 0.5f, 0.0f, 1.0f}
#define MAGENTA {1.0f, 0.0f, 1.0f, 1.0f}
#define WHITE {1.0f, 1.0f, 1.0f, 1.0f}

#include <QOpenGLWidget>
#include <QOpenGLFunctions>
#include <QOpenGLShaderProgram>
#include <QOpenGLBuffer>
#include <QOpenGLVertexArrayObject>
#include <QTimer>
#include <QtMath>
#include <vector>
#include <QPainter>
#include <QOpenGLPaintDevice>

#include "decoder-module/databridge.h"

// typedef struct{
//     double tm;
//     std::vector<double> val;
// }smp;

class MyGLWidget : public QOpenGLWidget, protected QOpenGLFunctions
{
    Q_OBJECT

public:
    explicit MyGLWidget(QWidget *parent = nullptr, double in_t_range_max = 0, double in_v_max = 0, double in_v_min = 0, QString v_unit = "V",
                        double in_fc = 0, double in_ft = 0,
                        std::vector<std::vector<GLfloat>> in_tcolors = {RED},
                        unsigned int in_division_for_v_axi = 6, unsigned int in_division_for_h_axi = 10);

    ~MyGLWidget();


    //-----
    double t_range_max;
    double t_range;
    std::vector<double>t_moltiplicators = {1, 0.5, 0.2, 0.05, 0.02, 0.01, 0.005, 0.002, 0.001};
    unsigned t_moltilicator_index;

    double v_max;
    double v_min;
    double v_sup;
    double v_inf;
    std::vector<double>v_moltiplicators = {1, 0.5, 0.2, 0.05, 0.02, 0.01, 0.005, 0.002, 0.001};
    unsigned v_moltilicator_index;
    QString v_measure_unit;

    // funzione usata per trasformare in stringa i dati, oltre alla conversione verifica che l'unità di misura sia scalabile e nel caso ne resti
    // tuisce il valore scalato con l'ordine di misura corretto.
    QString setOrderUnit(double data, QString ref_unit);

    // variabile per impostare numero di divisioni, per ora la lascio fissa, non impostabile esternamente
    unsigned int division_for_vertical_axi;
    unsigned int division_for_horizontal_axi;

    std::vector<std::vector<GLfloat>> tcolors;


    // variabili per gestire il filtro passa basso (usato in modo tale che il segnale risulti come filtrato con passa alto)
    bool filter_mode;
    double prev_smp_filtered;
    double filter_coefficient;
    double ft;
    //-----

    // definizione della variabile points in base al valore delle variabili fornite al costruttore dell'oggetto, magari si
    // potrebbero aggiungere altri points oltre a quelli calcolati con la formula per non avere nessun problema di visualizzazione
    // quando il t_scale impostato è esattamente t_scale_max.
    // unsigned points = (t_scale_max/(1.0/fc));
    unsigned points;
    double fc;




    // variabile per tenere traccia del tempo totale di acquisizione del segnale
    // non la ho dichiarata unsigned int perchè poi nel ciclo for i è int
    int mem_index_data_buffer;
    double tot_time_acquisition;
    // variabili per implementare la modalità statica
    bool realtime_mode;
    double instant_tot_time_acquisition;
    double static_time_acquisition;
    int unsigned index_static_tail_data_buffer;
    int unsigned instant_index_tail_data_buffer;

    // vettore usato per scrivere i dati in arrivo da file, valuta se metterla in private e scrivere un metodo
    // in public per permetterne la manipolazione solo attraverso esso, con il multi  traccia potrebbe avere molto senso perchè
    // si verifica che vengano passati a data_buffer strutture smp che abbiano sufficienti dati per disegnare i tracciati dichiarati in fase
    // di istanza alla classe
    int unsigned index_tail_data_buffer;

    //  variabili per gestire multi traccia, l'idea sarebbe quella di usare sempre un solo vbo che però è ovviamente più
    // complesso da gestire e quindi, per fare ciò servono alcune variabili aggiuntive
    unsigned int traces;


    void changeVertex();



protected:
    void initializeGL() override;
    void resizeGL(int w, int h) override;
    void paintGL() override;

private:
    // vettore usato per tenere in memoria i dati passati dal main, in private in modo che sia possibile la modifica
    // solo attraverso il metodo loadDatabuffer il quale applica controlli sul dato per evitare comportamenti imprevisti
    // del programma
    std::vector<smp> data_buffer;

    QOpenGLShaderProgram *m_program = nullptr;

    // variabili per disegno del segnale
    QOpenGLBuffer m_vbo_data;
    QOpenGLVertexArrayObject m_vao_data;

    //timer usato per trigger animazione
    QTimer *timer = nullptr;

    //buffer usato per riempire m_vbo
    std::vector<GLfloat> m_vbo_data_buffer;

    //vettori da usare per disegnare la griglia.
    QOpenGLBuffer m_vbo_grid;
    QOpenGLVertexArrayObject m_vao_grid;
    std::vector<GLfloat> m_vbo_grid_buffer;


public slots:

    // per gestioni eventi interfaccia
    // aumento diminuzione di t_scale e v_scale
    void modifyTscaleInc();
    void modifyTscaleDec();
    void modifyVscaleInc();
    void modifyVscaleDec();

    // per modificare la finestra temporale dove si vuole visualizzare il segnale
    void modifyTimeWindow(int val);
    void modifyMod(bool m);

    //per applicazione filtro
    void modifyFilterMod(bool m);

    // metodo usato per inserire in data_buffer i dati
    void loadDatabuffer(smp sample);

signals:

    void TscaleUpdated(QString s_division);
    void VscaleUpdated(QString s_division, QString s_max, QString s_min);
    void ModUpdated(QString s);
    void TimeUpdated(QString s, QString s_max, QString s_min);
    void LogUpdated(QString s);

};

#endif // MYGLWIDGET_H
