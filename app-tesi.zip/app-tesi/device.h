#ifndef DEVICE_H
#define DEVICE_H

#include <QObject>
#include <QLowEnergyController>
#include <QBluetoothDeviceInfo>

class MyDevice : public QObject {
    Q_OBJECT

public:
    explicit MyDevice(QObject *parent = nullptr);
    void connectToMyDevice(const QBluetoothDeviceInfo &info);

private slots:
    void onConnected();
    void onDisconnected();

private:
    //la variabile principale di tutta la classe, sarebbe quella che gestisce effettivamente il dispositivo connesso
    // in termini di interazioni trasmissive
    QLowEnergyController *controller = nullptr;
};

#endif // DEVICE_H
