// decoder.cpp:
// Program to decode bluetooth streams from the EMGyro2 device.
// (C) 2019-2020 Giorgio Biagetti

#include "decoder.h"

#include <cstdint>
#include <cstdio>

// singleton definitions:

emg_decoder emg;
gyr_decoder gyr;


// Implementation of class emg_decoder:

emg_decoder::emg_decoder () : channels(0), datarate(0), batmode{false}
{
	config = 0xC0; // a value that is not allowed.
}

/* EMG subchannel 0 data structure:
 *	BYTE 0:   // ADC configuration:
 *		reserved     : 2; // set to zero for now
 *		num_channels : 2; // 1 ÷ 3
 *		odr_index    : 4; // 0 ÷ 7 => 50 100 200 400 800 1600 3200 6400
 *	BYTE 1÷3: // EMG channels 1÷3 definitions as follows:
 *		test_mode    : 2; // 0 ÷ 3 => normal pos_test neg_test zero_test
 *		pos_channel  : 3; // 0 => OFF, 1÷6 => electrode number, 7 => battery
 *		neg_channel  : 3; // 0 => OFF, 1÷6 => electrode number, 7 => battery
 */
bool emg_decoder::setup (unsigned config)
{
    //per TEST, osservazione, in base al numero di canali attivi ottenuto leggendo i bit 4 e 5
    // del primo byte di config allora i dati in v sono diversi da 0 (con 0 intendo anche valori estremamente piccoli
    // come 10^-310) resta comunque un problema, come faccio a capire da chi proviene il dato (da quale canale)?
    // SOLUZIONE: non esiste un vero e proprio canale hardware, durante l'acquisizione, leggendo i byte 1 2 e 3 si capisce la configurazione di misura
    // e da questa si definiscono quanti canali bisogna distinguere (in realtà questa informazione si trova scritta anche nei primi 8 bit di confing).
    // Il caso di default è quello che prevede l'utilizzo di 6 elettodi usati a coppie di 2 quindi esisteranno 3 canali diversi (uno per ogni segnale).

    // config = 0x37003728; //canali in normal mode tranne il canale 2 che è spento
    // config = 0x37373738; // canali in normal mode
    // config = 0x37370028; // canali in normal mode tranne il canale 1 che è spento

    channels = (config & 0x30) >> 4; // contains number from 1 to 3
	datarate = (config & 0x0F) >> 0; // contains 1 + log2(ODR / 100Hz)
	datarate = 50 << datarate;
    if (channels && !(config >> 8)) {
        return false;
    }
    if (config == this->config) return false;
    this->config = config;

    batmode[0] = (config >>  8) & 0xFF == 0077;
	batmode[1] = (config >> 16) & 0xFF == 0077;
	batmode[2] = (config >> 24) & 0xFF == 0077;
	fprintf(stderr, "%s %d Hz", "EMG setup:", datarate);
	for (unsigned i = 1; i <= channels; ++i) {
		fprintf(stderr, " CH%u:", i);
		uint8_t mode = config >> (8 * i);
		uint8_t test = mode >> 6;
		if (test)
			fprintf(stderr, "%c", "+-0"[test - 1]);
		else if (mode == 0077)
			fprintf(stderr, "%s", "BAT");
		else
			fprintf(stderr, "%d-%d", mode >> 3, mode & 7);
	}
	fprintf(stderr, "\n");
	return true;
}

void emg_decoder::decode (unsigned const *data, double *out)
{
	const double     vref = 2.4;
	const double  batgain = 3.246;
	const double  ecggain = 2 / 3.5;
	const uint32_t adcmax = 0x800000;
	for (unsigned i = 0; i < channels; ++i) {
		double v = ((double) data[i] / adcmax - 0.5);
		if (batmode[i]) {
			// battery voltage
			v *= batgain;
			v += 1;
		} else {
			// standard channel
			v *= ecggain;
		}
		out[i] = v * vref;
	}
}


// Implementation of class gyr_decoder:

gyr_decoder::gyr_decoder () : interval(0), gyr_range(0), acc_range(0)
{
	config = 0x100; // a value that is not allowed.
}

/* GYR subchannel 0 data structure:
 *	BYTE 0:   // configuration:
 *		odr_index     : 4; // 1 ÷ 10 => 12.5 ÷ 6666 [Hz]
 *		gyr_fullscale : 2; // 0 ÷ 3  => 250 500 1000 2000 [dps]
 *		acc_fullscale : 2; // 0 ÷ 3  => 2 4 8 16 [g]
 *	BYTE 1÷3: // reserved for future use.
 */
bool gyr_decoder::setup (unsigned config)
{
	if (config == this->config) return false;
	this->config = config;
	interval = config >> 4; // contains 1 + log2(ODR * 0.0768 s)
	interval = 153600000 >> interval;
	gyr_range = 250 << (config >> 2 & 0x03);
	acc_range =   2 << (config >> 0 & 0x03);
	fprintf(stderr, "%s %.4f Hz  %d dps  %d g\n", "GYR setup:", 1E9 / interval, gyr_range, acc_range);
	return true;
}

void gyr_decoder::decode (unsigned const *data, double *out)
{
	const int fs[] = {gyr_range, acc_range}; // full-scale [dps, g]
	out[0] = (int16_t) data[0] * (1.0 / 256) + 25;
	for (unsigned i = 1; i <= 6; ++i)
		out[i] = (double) (int16_t) data[i] / 0x8000 * fs[(i - 1) / 3];
}
