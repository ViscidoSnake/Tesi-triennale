// decoder.h:
// Program to decode bluetooth streams from the EMGyro2 device.
// (C) 2019-2020 Giorgio Biagetti

#ifndef DECODER_H
#define DECODER_H

class emg_decoder
{
public:
	emg_decoder ();
	bool setup  (unsigned config);
	void decode (unsigned const *data, double *out);
	int  channels;
	int  datarate;
    // config in pubic così reciver può leggere il valore di essa e mandarlo fuori dall'oggetto
    unsigned config;


private:
    // unsigned config;
	bool batmode[3];
};

class gyr_decoder
{
public:
	gyr_decoder ();
	bool setup  (unsigned config);
	void decode (unsigned const *data, double *out);
	int  interval;
    // scritto le due variabili come public così che risultino leggibili dall'esterno, in particolare da reciver che deve
    // farle uscire da esso
    int  gyr_range;
    int  acc_range;
    unsigned config;
private:
    // unsigned config;
    // int  gyr_range;
    // int  acc_range;
};

extern emg_decoder emg;
extern gyr_decoder gyr;


#endif
