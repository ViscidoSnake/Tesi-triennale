#include "databridge.h"

dataBridge::dataBridge(QObject *parent)
    : QObject{parent}
{
    // qDebug() << "oggetto dataBridge creato";
}

dataBridge::~dataBridge(){
    // qDebug() << "oggetto dataBridge distrutto";
}



void dataBridge::emitGYRdataTemp(smp data){
    emit GYRdataTemp(data);
}

void dataBridge::emitGYRdataVel(smp data){
    emit GYRdataVel(data);
}

void dataBridge::emitGYRdataAcc(smp data){
    emit GYRdataAcc(data);
}

void dataBridge::emitEMGdataScreen1(smp data){
    emit EMGdataScreen1(data);
}

void dataBridge::emitEMGdataScreen2(smp data){
    emit EMGdataScreen2(data);
}

void dataBridge::emitEMGdataScreen3(smp data){
    emit EMGdataScreen3(data);
}



// per inviare dati setup dei decoder
void dataBridge::emitDecodersSetupData(decoders_setup_data data){
    emit decodersSetupData(data);
}
