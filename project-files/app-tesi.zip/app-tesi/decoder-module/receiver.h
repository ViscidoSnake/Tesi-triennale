// receiver.h:
// Program to decode bluetooth streams from the EMGyro2 device.
// (C) 2019-2020 Giorgio Biagetti

#ifndef RECEIVER_H
#define RECEIVER_H

#include <string>
#include <cstdint>
#include "databridge.h"

// abstract base class for output handling:
class outport
{
public:
	virtual void operator () (std::string const &type, uint64_t time, unsigned sample, unsigned const *data = 0) = 0;
};


// only one instance of the class receiver can exist!
// call operator () for every received packet and at most every 10 ms!
// this class will take care of calling all the registered outports
// after the appropriate latency.
// call flush() at the end to flush latency buffers.


class receiver
{
public:
    receiver (dataBridge* bridge);
    ~receiver();
	void setup (double drift);
	void operator () (uint64_t time, std::string const &type = "", std::string const &data = "");
	void add_port (outport &port, uint64_t latency = 0);
	void flush ();
	void dump ();
    // variabile necessaria per far uscire i dati dagli oggetti decoder
    dataBridge* bridge;
    // variabile che uso per essere sicuro che lo stato dei decoder sia inizializzato e quindi poi
    // emettere il segnale attraverso il membro bridge
    bool decodersInizialized;
};

#endif
