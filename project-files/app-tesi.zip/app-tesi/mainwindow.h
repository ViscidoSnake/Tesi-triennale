#ifndef MAINWINDOW_H
#define MAINWINDOW_H
// rispetto alla v5 inserimento del decoder + modifica per la disconnessione, nulla di nuovo ma semplicemente ho messo un metodo public per farlo, senza dover
// avere un segnale e uno slot, credo di aver semplificato

// comentato i trow nel codice receiver, quelli mostarti al prof

// cambiamento del discovery agent impostato per essere EFFETTIVAMENTE continuo!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

#include <QMainWindow>
#include <QBluetoothDeviceDiscoveryAgent>
#include <QBluetoothDeviceInfo>
#include <QLowEnergyController>
#include <QDateTime>
#include <QScrollBar>
#include <QButtonGroup>
#include <QScrollArea>
#include <QPushButton>
#include <QVBoxLayout>
#include <QSlider>
#include <Qfile>


#include "myemgyro2.h"
#include "myglwidget.h"


struct favorite_device{
    QString nickname;
    QString MAC_address;
};

struct device_obj{
    QBluetoothDeviceInfo BLE_device;
    QString address;
    QString name;
    QString nickname;
};

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE


class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    Ui::MainWindow *ui;
    // per gestione filtro dei messaggi di log
    QButtonGroup *filter_log_group;
    // la variabile è utile perche altrimenti dovrei richiedere ogni volta che arriva un log lo stato dei pulsanti al gruppo  che li
    // raccoglie
    unsigned int selected_radiobutton;

    // per gestione filtro dei device trovati durante la scansione
    QButtonGroup *filter_devices_group;

    //per gestione eventi interfaccia in particolare viene usata nella scrittura degli slot EMG / ECG!
    int active_channels;

    // per demo
    bool demo_mode = false;
    QTimer *timer_data;
    QFile fileGYR;
    QTextStream *streamGYR;
    QFile fileEMG;
    QTextStream *streamEMG;
    dataBridge *data_bridge;

    // ----------------------------

    // variabili e metodi per parte openGL
    MyGLWidget *ogl_screen_gyr_temp = nullptr,*ogl_screen_gyr_acc= nullptr,*ogl_screen_gyr_vel= nullptr;
    // MyGLWidget *ogl_screen_EMG_ch1,*ogl_screen_EMG_ch2, *ogl_screen_EMG_ch3; // dichiarazione per far funzionare 12 maggio
    MyGLWidget *ogl_screen_emg_1= nullptr,*ogl_screen_emg_2= nullptr, *ogl_screen_emg_3= nullptr;


    // funzione usata per fare il replace degli schermi openGL creati inizialmente nel file ui
    MyGLWidget* replaceOpenGLscreen(QWidget* old_OpenGLscreen,
                                    QGridLayout* layout,
                                    double t_range_max, double v_max, double v_min, QString v_unit,
                                    float fc, double ft,
                                    std::vector<std::vector<GLfloat>> tcolors,
                                    unsigned int division_for_v_axi, unsigned int division_for_h_axi);

    // funzione per connettere gli schermi ai pulsanti nell'intrfaccia grafica
    void connectInputToOpenGLscreen(MyGLWidget* screen,
                                    QPushButton* t_scale_inc, QPushButton* t_scale_dec, QPushButton* v_scale_inc, QPushButton* v_scale_dec,
                                    QPushButton* static_selector, QSlider* static_slider, QPushButton* filter_mod);
    // funzione per connettere segnali degli schermi a slot nell'interfaccia
    void connectSignalsFromOpenGLscreen(MyGLWidget* screen,
                                        void (MainWindow::*updateTS)(QString) = &MainWindow::updateTscaleLabelEMG,
                                        void (MainWindow::*updateVS)(QString, QString, QString) = &MainWindow::updateVscaleLabelEMG,
                                        void (MainWindow::*updateLog)(QString) = &MainWindow::updateLogEMG,
                                        void (MainWindow::*updateMod)(QString) = &MainWindow::updateModEMG,
                                        void (MainWindow::*updateTime)(QString, QString, QString) = &MainWindow::updateTimeEMG);


public slots:

    // servono per gestire i segnali che le classi usate per lavorare con BLE emettono
    void deviceDiscovered(const QBluetoothDeviceInfo &device);
    void scanFinished();

    void ableScanAndConnection();
    void disableScanAndConnection();

    void startScan();
    void stopScan();


    // // slot per ricevere il pacchetto dati dal servizio EMG
    // void EMGdataStreaming(smp data);
    // // slot per ricevere il pacchetto dati dal servizio device, cioè i dati di telemetria
    // void deviceDataStreaming(float v);
    // // slot per ricevere il pacchetto dati dal servizio Gyr, cioè i dati dei giroscopi
    // void GYRdataStreaming(smp data);

    // sarebbe lo slot che usa la classe MyGyro2 per dare aggiornamenti sullo stato della connessione
    void updateLog(QString s);


    // sarebbe lo slot usato per applicare i filtri ai device trovati in fase di scansione
    void deviceFilter();
    // slot usato per riscrivere il placejolder ogni volta che il criterio di filtraggio dei device varia
    void rewritePlaceholder(int id);


    // sarebbe lo slot per connetersi al device che è stato selezionato nella tabella
    void tryToConnectToDevice();
    void tryToDisconnectToDevice();

    // --------------------------------

    // per gestione eventi interfaccia EMG
    void updateTscaleLabelEMG(QString s_division);
    void updateVscaleLabelEMG(QString s_division, QString s_max, QString s_min);
    void updateModEMG(QString d);
    void updateTimeEMG(QString s, QString s_max, QString s_min);
    void updateLogEMG(QString s);

    // per gestione eventi derivanti da GYRtemp
    void updateTscaleLabelGYRtemp(QString s_division);
    void updateVscaleLabelGYRtemp(QString s_division, QString s_max, QString s_min);
    void updateModGYRtemp(QString d);
    void updateTimeGYRtemp(QString s, QString s_max, QString s_min);
    void updateLogGYRtemp(QString s);

    // per gestione eventi derivanti da GYRacc
    void updateTscaleLabelGYRacc(QString s_division);
    void updateVscaleLabelGYRacc(QString s_division, QString s_max, QString s_min);
    void updateModGYRacc(QString d);
    void updateTimeGYRacc(QString s, QString s_max, QString s_min);
    void updateLogGYRacc(QString s);

    // per gestione eventi derivanti da GYRvel
    void updateTscaleLabelGYRvel(QString s_division);
    void updateVscaleLabelGYRvel(QString s_division, QString s_max, QString s_min);
    void updateModGYRvel(QString d);
    void updateTimeGYRvel(QString s, QString s_max, QString s_min);
    void updateLogGYRvel(QString s);

    // ------------------------------------------------
    // slot necessario per ricevere i dati di configurazione dei decoder e quindi la
    // configurazione di acquisizione della scheda
    void setupGLscreens(decoders_setup_data data);

    // per demo
    void demo();
    void demoIndataGYR();
    void demoIndataEMG();

signals:
    // void deviceDisconnectionRequest();
    // segnale usato internamenta dalla stessa classe per aggiornare il log, ha lo stesso nome
    // del segnale usato dalla classe MyGyro2 proprio perchè la funzione è la stessa
    void LogUpdated(QString s);
    void tryConnection();
    void disconnectionRequest();

    // per demo
    void demoGYRaccData(smp sample);
    void demoGYRvelData(smp sample);
    void demoGYRtempData(smp sample);
    void demoEMGch1Data(smp sample);
    void demoEMGch2Data(smp sample);
    void demoEMGch3Data(smp sample);

private:
    // VARIABILI USATE PER CONNESSIONE BLE
    QBluetoothDeviceDiscoveryAgent *m_discovery_agent = nullptr;
    std::vector<device_obj> device_discovered_list;
    MyEMGyro2 *device = nullptr;
    // variabile usata per mantenere in memoria i dispositivi preferiti
    std::vector<favorite_device> favorite_devices = {
                                                     {"Dispositivo MyGyro2 braccio destro","FB:03:6F:AC:04:0B"}
    };
    // variabile usata per oggetto che fa da ponte tra l'oggetto reciver e il mainwindow
    dataBridge *dataOut = nullptr;


};

#endif // MAINWINDOW_H
