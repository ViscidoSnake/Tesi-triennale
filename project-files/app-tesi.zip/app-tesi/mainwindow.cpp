#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // per rendere dinamiche larghezza delle colonne della tabella
    ui->list_of_discovered_devices_table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    // connessioni per gestre scansione on/off con i pulsanti
    connect(ui->start_scan_button, &QPushButton::clicked, this, &MainWindow::startScan);
    connect(ui->stop_scan_button, &QPushButton::clicked, this, &MainWindow::stopScan);
    // connessioni per gestire connessione on/off con i pulsanti e la tabella
    connect(ui->connect_button, &QPushButton::clicked, this, &MainWindow::tryToConnectToDevice);
    connect(ui->disconnect_button, &QPushButton::clicked, this, &MainWindow::tryToDisconnectToDevice);

    // connessione per aggiornare il log dell'interfaccia anche con eventi "interni" principalemte quelli che riguardano la scansione
    // dei device
    connect(this, &MainWindow::LogUpdated, this, &MainWindow::updateLog);

    // inserimento dei pulsanti per filtrare i messaggi di log in un gruppo in modo che sia molto facile gestirli, usando QButtonGroup
    // non serve neanche scrivere gli slot per intercettare gli eventi di scelta, basta semplicemente
    // interrogare il gruppo di pulsanti quando necessario e agire di conseguenza, oltre a questo non si deve nemmeno gestire il problema
    // di doppie selezioni o nessuna selezione
    filter_log_group = new QButtonGroup(this);
    filter_log_group->addButton(ui->all_radiobutton, 0); // assegnato ID = 0 a all_radiobutton
    filter_log_group->addButton(ui->normal_radiobutton, 1); // assegnato ID = 1 a normal_radiobutton
    ui->all_radiobutton->setChecked(true);
    // filter_log_group->addButton(ui->basic_radiobutton, 2); // assegnato ID = 2 a basic_radiobutton

    // gestione pulsanti di selezione per filtraggio dei device
    // come per il caso dei bottoni per filtro dei messaggi di log
    filter_devices_group = new QButtonGroup(this);
    filter_devices_group->addButton(ui->name_filter_radiobutton, 0); // assegnato ID = 0 a name_filter_radiobutton
    filter_devices_group->addButton(ui->nickname_filter_radiobutton, 1); // assegnato ID = 1 a nickname_filter_radiobutton
    ui->name_filter_radiobutton->setChecked(true);
    // connessione pulsante per applicare i filtri
    connect(ui->filter_button, &QPushButton::clicked, this, &MainWindow::deviceFilter);
    // connessione degli eventi per cambiare il placeholder scritto nella barra dove scrivere la barra stringa da ricercare
    connect(filter_devices_group, &QButtonGroup::idClicked, this, &MainWindow::rewritePlaceholder);

    // impostazione che permette di selezionare solo righe della tabella
    ui->list_of_discovered_devices_table->setSelectionBehavior(QAbstractItemView::SelectRows);
    // impostazione che permette di selezionare solo una singola riga della tabella
    // ui->list_of_discovered_devices_table->setSelectionMode(QAbstractItemView::SingleSelection);

    //connessione pulsante demo con lo slot demo
    connect(ui->demo_button, &QPushButton::clicked, this, &MainWindow::demo);


    // NOTA la costruzione effettiva dell'interfaccia openGL va fatta solo dopo che i decoder in reciver (questo presuppone che
    // il tentativo di connessione alla scheda sia andato a buon fine ) hanno ultimato il setup e notificato tale evento attraverso emissione
    // di un segnale della classe dataBridge la quale viene creata ogni volta che si tenta una connessione, il connect sta pertanto nella
    // tryToConnectToDevice

    setCentralWidget(ui->tabs);
}

MainWindow::~MainWindow() {
}



void MainWindow::updateTimeEMG(QString s, QString s_max, QString s_min){
    ui->EMG_time->setText(s);

    // sono presenti nell'interfaccia 3 schermi EMG/ECG quindi
    ui->EMG_first_t_1->setText(s_max);
    ui->EMG_last_t_1->setText(s_min);
    ui->EMG_first_t_2->setText(s_max);
    ui->EMG_last_t_2->setText(s_min);
    ui->EMG_first_t_3->setText(s_max);
    ui->EMG_last_t_3->setText(s_min);

}

void MainWindow::updateTscaleLabelEMG(QString s_division){
    // qDebug()<< t;
    ui->EMG_t_scale_val->setText(s_division);
}

void MainWindow::updateVscaleLabelEMG(QString s_division, QString s_max, QString s_min){
    // qDebug()<< t;
    ui->EMG_v_scale_val->setText(s_division);

    ui->EMG_v_max_1->setText(s_max);
    ui->EMG_v_min_1->setText(s_min);
    ui->EMG_v_max_2->setText(s_max);
    ui->EMG_v_min_2->setText(s_min);
    ui->EMG_v_max_3->setText(s_max);
    ui->EMG_v_min_3->setText(s_min);

}

void MainWindow::updateModEMG(QString s){
    ui->EMG_time_mod->setText(s);
    // ui->EMG_time->setText(QString::number(d.val,'d',3)+"s");

    // slocco barra slider se il pulsante è premuto e inoltre log che avverte del cambio di modalità
    if(ui->EMG_static_selector->isChecked()) {
        ui->EMG_static_slider->setEnabled(true);
    }
    else {
        // se non premuto (rilasciato) la barra viene bloccata e settata ad un valore iniziale di 99 (massimo)
        // e inoltre log che avverte del cambio di modalità
        ui->EMG_static_slider->setValue(99);
        ui->EMG_static_slider->setEnabled(false);
    }


}

void MainWindow::updateLogEMG(QString s){

    QString now = "[" + QTime::currentTime().toString("HH:mm:ss") + "] ";
    ui->EMG_log->appendPlainText(now + s);
    // scroll automatico in fondo, dove è stato appena aggiunto il messaggio di log
    QScrollBar *scrollbar = ui->EMG_log->verticalScrollBar();
    scrollbar->setValue(scrollbar->maximum());

}





void MainWindow::updateTimeGYRtemp(QString s, QString s_max, QString s_min){
    ui->GYRtemp_time->setText(s);
    ui->GYRtemp_first_t->setText(s_max);
    ui->GYRtemp_last_t->setText(s_min);
}

void MainWindow::updateTscaleLabelGYRtemp(QString s_division){
    // qDebug()<< t;
    ui->GYRtemp_t_scale_val->setText(s_division);
}

void MainWindow::updateVscaleLabelGYRtemp(QString s_division, QString s_max, QString s_min){
    // qDebug()<< t;
    ui->GYRtemp_v_scale_val->setText(s_division);
    ui->GYRtemp_v_max->setText(s_max);
    ui->GYRtemp_v_min->setText(s_min);
}

void MainWindow::updateModGYRtemp(QString s){
    ui->GYRtemp_time_mod->setText(s);
    // ui->EMG_time->setText(QString::number(d.val,'d',3)+"s");

    // slocco barra slider se il pulsante è premuto e inoltre log che avverte del cambio di modalità
    if(ui->GYRtemp_static_selector->isChecked()) {
        ui->GYRtemp_static_slider->setEnabled(true);
    }
    else {
        // se non premuto (rilasciato) la barra viene bloccata e settata ad un valore iniziale si 99 (massimo)
        // e inoltre log che avverte del cambio di modalità
        ui->GYRtemp_static_slider->setValue(99);
        ui->GYRtemp_static_slider->setEnabled(false);
    }


}

void MainWindow::updateLogGYRtemp(QString s){

    QString now = "[" + QTime::currentTime().toString("HH:mm:ss") + "] ";
    ui->GYRtemp_log->appendPlainText(now + s);
    // scroll automatico in fondo, dove è stato appena aggiunto il messaggio di log
    QScrollBar *scrollbar = ui->GYRtemp_log->verticalScrollBar();
    scrollbar->setValue(scrollbar->maximum());


}



void MainWindow::updateTimeGYRacc(QString s, QString s_max, QString s_min){
    ui->GYRacc_time->setText(s);
    ui->GYRacc_first_t->setText(s_max);
    ui->GYRacc_last_t->setText(s_min);
}

void MainWindow::updateTscaleLabelGYRacc(QString s_division){
    // qDebug()<< t;
    ui->GYRacc_t_scale_val->setText(s_division);
}

void MainWindow::updateVscaleLabelGYRacc(QString s_division, QString s_max, QString s_min){
    // qDebug()<< t;
    ui->GYRacc_v_scale_val->setText(s_division);
    ui->GYRacc_v_max->setText(s_max);
    ui->GYRacc_v_min->setText(s_min);
}

void MainWindow::updateModGYRacc(QString s){
    ui->GYRacc_time_mod->setText(s);
    // ui->EMG_time->setText(QString::number(d.val,'d',3)+"s");

    // slocco barra slider se il pulsante è premuto e inoltre log che avverte del cambio di modalità
    if(ui->GYRacc_static_selector->isChecked()) {
        ui->GYRacc_static_slider->setEnabled(true);
    }
    else {
        // se non premuto (rilasciato) la barra viene bloccata e settata ad un valore iniziale si 99 (massimo)
        // e inoltre log che avverte del cambio di modalità
        ui->GYRacc_static_slider->setValue(99);
        ui->GYRacc_static_slider->setEnabled(false);
    }


}

void MainWindow::updateLogGYRacc(QString s){

    QString now = "[" + QTime::currentTime().toString("HH:mm:ss") + "] ";
    ui->GYRacc_log->appendPlainText(now + s);
    // scroll automatico in fondo, dove è stato appena aggiunto il messaggio di log
    QScrollBar *scrollbar = ui->GYRacc_log->verticalScrollBar();
    scrollbar->setValue(scrollbar->maximum());

}




void MainWindow::updateTimeGYRvel(QString s, QString s_max, QString s_min){
    ui->GYRvel_time->setText(s);
    ui->GYRvel_first_t->setText(s_max);
    ui->GYRvel_last_t->setText(s_min);
}

void MainWindow::updateTscaleLabelGYRvel(QString s_division){
    // qDebug()<< t;
    ui->GYRvel_t_scale_val->setText(s_division);
}

void MainWindow::updateVscaleLabelGYRvel(QString s_division, QString s_max, QString s_min){
    // qDebug()<< t;
    ui->GYRvel_v_scale_val->setText(s_division);
    ui->GYRvel_v_max->setText(s_max);
    ui->GYRvel_v_min->setText(s_min);
}

void MainWindow::updateModGYRvel(QString s){
    ui->GYRvel_time_mod->setText(s);
    // ui->EMG_time->setText(QString::number(d.val,'d',3)+"s");

    // slocco barra slider se il pulsante è premuto e inoltre log che avverte del cambio di modalità
    if(ui->GYRvel_static_selector->isChecked()) {
        ui->GYRvel_static_slider->setEnabled(true);
    }
    else {
        // se non premuto (rilasciato) la barra viene bloccata e settata ad un valore iniziale si 99 (massimo)
        // e inoltre log che avverte del cambio di modalità
        ui->GYRvel_static_slider->setValue(99);
        ui->GYRvel_static_slider->setEnabled(false);
    }


}

void MainWindow::updateLogGYRvel(QString s){


    QString now = "[" + QTime::currentTime().toString("HH:mm:ss") + "] ";
    ui->GYRvel_log->appendPlainText(now + s);
    // scroll automatico in fondo, dove è stato appena aggiunto il messaggio di log
    QScrollBar *scrollbar = ui->GYRvel_log->verticalScrollBar();
    scrollbar->setValue(scrollbar->maximum());


}
















