#include "myglwidget.h"

MyGLWidget::MyGLWidget(QWidget *parent, double in_t_range_max, double in_v_max,double in_v_min, QString in_v_measure_unit,
                       double in_fc, double in_ft,
                       std::vector<std::vector<GLfloat>> in_tcolors,
                       unsigned int in_division_v_axi, unsigned int in_division_h_axi) :
    QOpenGLWidget(parent), t_range_max(in_t_range_max), v_max(in_v_max), v_min(in_v_min), v_measure_unit(in_v_measure_unit),
    division_for_vertical_axi(in_division_v_axi), division_for_horizontal_axi(in_division_h_axi),
    tcolors(in_tcolors),
    ft(in_ft), fc(in_fc)
{
    // definizione della variabile points, fondamentale per "oggetti" openGL
    points = (t_range_max/(1.0/fc));
    // in base ai colori indicati si deduce quanti tracciati si vorranno disegnare
    traces = tcolors.size();

    // inizializzo variabile che definisce il numero di divisioni per asse
    // division_for_horizontal_axi = 10;
    // division_for_vertical_axi = 6;

    // inizializzazione scala orizzontale
    t_moltilicator_index = 0;
    t_range = t_range_max * t_moltiplicators[t_moltilicator_index];

    // inizializzazione scala verticale, considerazione, essendo che in v_moltiplicators i coefficienti inseriti faranno ottenere soglie sempre più
    // piccole delle massime indicate in fase di istanza è necessario che queste ultime siano abbastanza grandi da comprendere l'intero segnale.
    v_moltilicator_index = 0;
    v_sup = v_max * v_moltiplicators[v_moltilicator_index];
    v_inf = v_min * v_moltiplicators[v_moltilicator_index];

    // definizione delle variabili necessarie per il funzionamento del filtro
    filter_mode = false;
    filter_coefficient = (2 * M_PI * ft) / ((2 * M_PI * ft) + fc);

    // start in realtime, assegnazione dei valori iniziali alle variabili
    realtime_mode = true;
    mem_index_data_buffer = 0;
    tot_time_acquisition = 0;
    instant_tot_time_acquisition = 0;
    index_static_tail_data_buffer = 0;
    instant_index_tail_data_buffer = 0;
}

MyGLWidget::~MyGLWidget()
{
    //ricordati di usare makeCurrent() all'inizio del costruttore
    makeCurrent();
    delete m_program;
    delete timer;
    m_vbo_data.destroy();
    m_vao_data.destroy();
    m_vao_grid.destroy();
    m_vbo_grid.destroy();
    doneCurrent();
}

// valuta se scrivere questi avvisi in modo più chiaro, se infatti ci sono più istane della classe è impossibile riconoscere
// da quale istanza proviene l'errore, l'ideale sarebbe emettere un signal apposito che poi viene ricevuto da un log nella gui
void MyGLWidget::loadDatabuffer(smp sample){
    int n = traces - sample.val.size();
    if(n > 0){
        qDebug() << "non stai fornendo abbastanza dati rispetto alle tracce dichiarate!!!";
        // per evitare crash posso inserire dati palesemente finti che l'utente dovrebbe immediatamente capire che qualcosa non va
        // in questo caso la traccia per la quale non ci sono dati è ferma sullo 0
        sample.val.push_back(0);
    } else if(n < 0){
        qDebug() << "stai fornendo troppi dati rispetto alle tracce dichiarate!!!";
        // caso in cui lo schermo viene dichiarato come a singola traccia ma si forniscono più dati del dovuto, in questo caso per evitare
        // crash del programma si toglie dal sample un dati dal vettore val
        sample.val.pop_back();
    }

    data_buffer.push_back(sample);

}

void MyGLWidget::changeVertex(){

    if(data_buffer.size() == 0) return;

    index_tail_data_buffer = data_buffer.size() - 1;

    double tail_data_buffer = data_buffer[index_tail_data_buffer].tm;
    int index_offset_tail_data_buffer;
    bool short_data_buffer = false;

    // controllo che la lunghezza di data_buffer sia maggiore di points altrimenti nel for leggerei fuori da data_buffer
    // (esco dalla testa, vado oltre l'indice 0)
    if(index_tail_data_buffer + 1 < points) {
        index_offset_tail_data_buffer = -1;
        // setto la variabile che mi permette di gestire la situazione in cui il numero di dati in data_buffer è minore del
        // numero di punti da disegnare
        short_data_buffer = true;
    }
    else {
        index_offset_tail_data_buffer = index_tail_data_buffer - points;
        short_data_buffer = false;
    }


    //--------PER IL CALCOLO DINAMICO DEL TEMPO, MASSIMA PRECISIONE
    // per il calcolo del tempo totale di acquisizione, if serve per considerare solo gli ultimi campioni
    // arrivati in data_buffer, per come funziona è necessario che sia messa PRIMA della modalità statica perche altrimenti
    // mem_index_data_buffer assume i valori imposti con lo slider e non segue più lespansione di data_buffer.
    // per il calcolo del tempo totale di acquisizione, if serve per considerare solo gli ultimi campioni
    // arrivati in data_buffer, per come funziona è necessario che sia messa PRIMA della modalità statica perche altrimenti
    // mem_index_data_buffer assume i valori imposti con lo slider e non segue più lespansione di data_buffer.
    for (int i = index_tail_data_buffer; i > index_offset_tail_data_buffer; i--) {
        if(i > mem_index_data_buffer){
            tot_time_acquisition = tot_time_acquisition + (data_buffer[i].tm - data_buffer[i - 1].tm);
            // controllo se la modalità impostata è quella dinamica, nel caso permetto il time update sull'interfaccia;
            if(realtime_mode == true){
                // all'inizio può accadere che tot_time_acquisition sia < t_range, il risultato è che facendo TimeUpdated si visualizza
                // un valore negativo sulla label a sinistra dell'asse verticale, per evitare ciò conviene fissare a 0 questo valore fin tanto
                // che la disuguaglianza è vera
                double last_t = tot_time_acquisition - t_range;
                if(last_t < 0) last_t = 0;
                emit TimeUpdated(setOrderUnit(tot_time_acquisition, "s"),
                                 "NOW", setOrderUnit(last_t,"s"));
                // emit LogUpdated("P:real time upadated!");
            }
        }
    }
    mem_index_data_buffer = index_tail_data_buffer;
    //--------

    //--------PER IMPOSTAZIONE DELLA MODALITÀ STATICA (NORMALMENTE MODALITÀ DINAMICA)
    if(realtime_mode == false){
        // modalità statica
        // qDebug() << "index_static_tail_data_buffer da chang" << index_static_tail_data_buffer;
        // qDebug() << "index_tail_data_buffer da chang" << index_tail_data_buffer;

        index_tail_data_buffer = index_static_tail_data_buffer;

        tail_data_buffer = data_buffer[index_tail_data_buffer].tm;

        if(index_tail_data_buffer + 1 < points) {
            index_offset_tail_data_buffer = -1;
            short_data_buffer = true;
        }
        else{
            index_offset_tail_data_buffer = index_tail_data_buffer - points;
            short_data_buffer = false;
        }
    }
    //--------


    double d = 0;
    int k = 0;
    // int k_lim = 0;
    for (int i = index_tail_data_buffer; i > index_offset_tail_data_buffer; i--, k = k + 6) {
        // d sarebbe il valore temporale differenza calcolato come il tempo dell'ultimo campione in data_buffer meno
        // il tempo del campione immediatamente precedente ad esso.
        d = tail_data_buffer - data_buffer[i].tm;

        // scalo d in base al t_window impostato, d è sempre un valore maggiore di 0 quindi la moltiplicazione per il fattore
        // di scala è sempre un numero positivo. 1 - d scalato (( 2.0f / t_window ) * d)) mi permette di posizionare a ridosso
        // della coordinata 1 (estremità destra del widget) i campioni con valori temporali vicini al valore temporale del
        // campione più recente in data_buffer, infatti per i campioni immediatamente precedenti a quello in coda a data_buffer
        // d calcolato è molto piccolo e quindi la moltiplicazione per il fattore di scala e poi la sottrazione a 1 fa ottenere
        // una coordinata vicina a +1, per i campioni lontani dal campione in coda a data_buffer d è sempre più grande e quindi
        // le coordinate che si ottengono sono sempre più piccole (valori sempre più negativi e quindi che finiscono a sinistra
        // del widget).

        // qui devo usare la variabile traces, un for con una variabile iizializzata a 0 che si incrementa fino a traces
        for(unsigned int j = 0; j < traces; j++){
            // rimappatura delle coordinate x del campione
            m_vbo_data_buffer[k + (points*6)*j] = static_cast<GLfloat>( 1 - (( 2.0f / t_range) * d));

            // per la coordinata y del campione non effetuo in questo punto la rimappatura ma semplicemente momorizzo il valore da prendere da data_buffer
            m_vbo_data_buffer[k+1 + (points*6)*j] = static_cast<GLfloat>(data_buffer[i].val[j]);

        }

    }



    //--------PER GESTIONE DEI PUNTI DI m_vbo_data_buffer CHE NON SUBISCONO MODIFICHE PER ASSENZA DI DATI IN data_buffer
    // CONSIDERAZIONE, fin dalla creazione del primo frame openGL m_vbo ha caricate coordinate dei punti di inizializzazione assegnati a m_vbo_data_buffer
    // quando viene eseguita la initGL, operazione necessaria per garantire che tutti i punti abbiano il corretto colore assegnato, il punto è che
    // in questo modo, nelle fasi inizali, quando sono presenti pochi dati dal data buffer e quindi ne vengono sostituiti pochi in m_vbo_data_buffer e quindi
    // anche in m_vbo, succede che nella scena vengono disegnati punti di inizializzazione, per evitare questo brutto effetto si dovrebbe fare
    // in modo tale che i punti di inizializzazione vengano comunque processati in modo che collassino in corrispondenza dell'ultimo punto visibile nella
    // scena.

    // in condizioni "NORMALI" ovvero quando in data_buffer sono presenti almeno points campioni
    // k = sarebbe l'indice della coordinata x del primo vertice del terzo tracciato (caso con 2 soli tracciati),
    // in generale k rappresenta l'indice del primo vertice dei tracciati + 1, usare k in m_vbo_databuffer ovviamente comporta un errore in quanto
    // si tenta la lettura in una locazione di memoria esterna a m_vbo_data_buffer

    // se invece in data_buffer non ci sono abbastanza points allora k assume un significato diverso in quanto il ciclo for termina molto prima.
    // in questa situazione k rappresenta l'indice dell'ultima coordinata x dell'ultimo tracciato scritta basandosi sui dati presi in data_buffer
    // (che ricordo essere minori di points), in realtà per essere precisi questo accade per k - 6 (infatti ho definito a tale scopo k_lim = k - 6)
    // essendo che all'uscita del for k prima viene incrementato

    // usando k_lim si risale al
    // numero di posizioni che è necessario riscrivere in modo tale che si abbiano tutti vertici collassati sull'ultimo ovvero quindi quello
    // che ha coordinata x in corrispondenza di k_lim e coordinata y in k_lim+1, queste posizioni si ottengono come (posizioni totali per traccia)
    // - (posizioni scritte) ovvero (points*6) - (k_lim+1) quindi queste sono le posizioni da manipolare per fare in modo che una traccia abbia
    // i punti non scritti con dati collassati sull'ultimo che invece è scritto con un dato.

    // se si ragiona con n tracciati in pratica è come se esistessero n k_lim ciascuno distante dall'altro points*6

    if(short_data_buffer == true){
        // attenzione! i punti vanno collassati sempre sul punto ultimo ovvero quello in coda a m_vbo_data_buffer! quelli in testa sono le
        // coordinate dei campioni più recenti! (m_vbo_data_buffer nel for viene scritto dalla testa alla coda con dati presi dalla coda fino alla
        // coda - points di data_buffer (se coda - points non esce da data_buffer)).
        int k_lim = k - 6;
        for(unsigned int g = k_lim; g < (points*6 - 1 + 1); g = g + 6){

            for(unsigned int j = 0; j < traces; j++){
                // m_vbo_data_buffer[g + (points*6)*j] sarebbe la coordinata x non scritta con dati, quindi la eguaglio all'ultima effettivamente
                // ottenuta da con dati derivanti da data_buffer cioè m_vbo_data_buffer[k_lim + (points*6)*j]
                m_vbo_data_buffer[g + (points*6)*j] = m_vbo_data_buffer[k_lim + (points*6)*j];
                // discorso analogo a spra ma si prende la coordinata y
                m_vbo_data_buffer[g+1 + ((points*6)*j)] = m_vbo_data_buffer[k_lim+1 + (points*6)*j];
            }
        }
    }
    //--------

    // applico il filtro e faccio il remapping della coordinata y, tuttavia inizio dai campioni più vecchi ovvero quelli che si trovano sulla coda
    // di m_vbo_data_buffer, questo mi è utile per l'applicazione del filtro poichè questi campioni non verranno mai mostrati nella scena, o meglio
    // sono mostrati solo se si imposta il time scale massimo (in realtà neppure così perchè il ricalcolo con i coefficienti fa ottenere un numero
    // minore rispetto a quello usato per la definizione di points), essendo non visibili posso "inizializzare" il filtro con questi campioni senza preccu
    // parmi della risposta nel transitorio del filtro essendo questa non visibile, in altre parole lavoro lontano dagli occhi dell'utente.

    // questa caratteristica di avere dati in m_vbo_data_buffer che poi però non sono visualizabili sulla scena è più un bug, una mancanza di ottimizazione
    // che forse in versioni future verrà tolta tuttavia ora con la questione del filtro non si elimineranno tutti questi campioni ma solo alcuni (i più
    // distanti rispetto al più recente)

    // "inizializzazione" per evitare artefatto visivo anche al limite (tscale massimo)
    prev_smp_filtered = m_vbo_data_buffer[m_vbo_data_buffer.size()-4-1];
    for(int i = m_vbo_data_buffer.size()-1-4; i > -1; i=i-6){

        double smp_val = m_vbo_data_buffer[i];
        if(filter_mode){
            // applicazione del filtro passa basso
            double smp_val_filtered = filter_coefficient * smp_val + (1.0f - filter_coefficient) * prev_smp_filtered;
            // memoria del campione filtrato, mi serve per applicare il filtro al prossimo campione
            prev_smp_filtered = smp_val_filtered;

            // a questo punto mi basta effetuare la sottrazione tra il segnale originale e quello filtrato così da ottenere il valore
            // che si otterrebbe con un passa alto
            smp_val = smp_val - smp_val_filtered;
        }

        // funzione di remapping buona
        m_vbo_data_buffer[i] = static_cast<GLfloat>(2.0f * (smp_val - v_inf) / (v_sup - v_inf) - 1.0f);
    }



    m_vbo_data.bind();
    m_vbo_data.write(0, &(m_vbo_data_buffer[0]), traces * points * 6 * sizeof(GLfloat));


    update();
}

void MyGLWidget::initializeGL()
{
    //#####

    emit TscaleUpdated(setOrderUnit(t_range/division_for_horizontal_axi, "s"));
    emit VscaleUpdated(setOrderUnit((v_sup - v_inf)/division_for_vertical_axi, v_measure_unit),
                       setOrderUnit(v_sup, v_measure_unit), setOrderUnit(v_inf, v_measure_unit));
    //#####

    initializeOpenGLFunctions();

    // ####
    // START DEL TIMER PER AGGIORNAMENTO FRAME
    //start del timer
    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &MyGLWidget::changeVertex);
    //timeout del timer ogni 16 ms quindi animazione a 60 fps
    timer->start(16);

    // Shader di vertice
    const char *vertexShaderSource = R"(
        #version 330 core
        layout (location = 0) in vec2 aPos;
        layout (location = 1) in vec4 aColor;

        out vec3 vColor;
        out float vAlpha;

        void main()
        {
            gl_Position = vec4(aPos, 0.0f, 1.0);
            vColor = aColor.rgb;
            vAlpha = aColor.a;
        }
    )";

    // Shader di frammento
    const char *fragmentShaderSource = R"(
        #version 330 core

        in vec3 vColor;
        in float vAlpha;

        out vec4 FragColor;

        void main()
        {
           if(vAlpha == 0.0)
               discard;

           FragColor = vec4(vColor, 1.0);
        }
    )";
    // Creazione e compilazione shader
    m_program = new QOpenGLShaderProgram();
    m_program->addShaderFromSourceCode(QOpenGLShader::Vertex, vertexShaderSource);
    m_program->addShaderFromSourceCode(QOpenGLShader::Fragment, fragmentShaderSource);
    m_program->link();

    //#######
    //SETUP PER IL DISEGNO DEL SEGNALE

    //creazione del VBO
    m_vbo_data.create();
    m_vbo_data.bind();

    // essendo che nella change vertex viene gestito bene il caso dei punti di inizializzazione che comunque vengono stampati ma secondo una certa logi
    // ca ovvero tutti sovrapposti all'ultimo punto, l'inizializzazione di m_vbo_data_buffer può essere fatta con un qualsiasi valore numerico
    m_vbo_data_buffer.resize(traces * points * 6, 1.0f);
    // cambio il colore dei punti che si andranno a disegnare, utilizzo la variabile data in input al costruttore in fase di
    // istanza alla classe, uso approccio con i define molto pulito

    // first_coordinate è usata per impostare il colore trasparente per l'ultima coordinata di un tracciato e la prima coordinata di un altro
    // tracciato che nel m_vbo_data_buffer sono "adiacenti" se non si imposta la trasparenza si visualizza il segmento congiungente i due punti.
    bool first_coordinate = false;
    for(unsigned int i=0, j=1; i < traces * points * 6; i = i+6){
        // in pratica if serve per incrementare l'indice j ogni volta che tutte le coordinate di un tracciato sono state impostate
        // come colore (ogni traccia ha una lunghezza in m_vbo pari a points *6) quindi incremento j ogni volta che i assume valori multipli di
        // (points * 6), un pò brutto fare j-1 però è necessario poichè gli indici del vettore iniziano ovviamente da 0
        if(i == (points * 6) * j) {
            j++;
            // faccio i-1 perchè la l'unghezza di un tracciato è points*6 però gli indici vanno da 0 a points*6 - 1, in generale quindi
            // gli indici vanno da k fino a points*6 - 1 + k, se sono in points*6 - 1 + k in pratica mi trovo nella posizione in cui
            // è scritto il canale alpha dell'ultima coordinata del tracciato mentre se faccio points*6 - 1 + k + 6 mi trovo nella posizione
            // del canale alpha della prima coordinata del tracciato successivo al primo
            m_vbo_data_buffer[i-1] = 0.0f;
            m_vbo_data_buffer[i+5] = 0.0f;
            first_coordinate = true;
        }else first_coordinate = false;

        //caricamento nel canale r
        m_vbo_data_buffer[i+2] = static_cast<GLfloat>(tcolors[j-1][0]);
        //caricamento nel canale g
        m_vbo_data_buffer[i+3] = static_cast<GLfloat>(tcolors[j-1][1]);
        //caricamento nel canale b
        m_vbo_data_buffer[i+4] = static_cast<GLfloat>(tcolors[j-1][2]);
        //caricamento nel canale alpha, if serve per impedire che venga sovrascritto il canale alpha dei colori quandi
        // si sta scorrendo sulla coordinata critica ovvero quella che rappresenta l'inizione del nuovo tracciato
        if(first_coordinate == false) m_vbo_data_buffer[i+5] = static_cast<GLfloat>(tcolors[j-1][3]);

    }

    m_vbo_data.allocate(&(m_vbo_data_buffer[0]), traces * points * 6 * sizeof(GLfloat));
    // Creazione del VAO per disegno del segnale
    m_vao_data.create();
    m_vao_data.bind();
    //scrittura sul VAO riguardo la modalità di lettura del VBO contenente i vertici da disegnare
    m_program->bind();
    m_program->setAttributeBuffer(0, GL_FLOAT, 0, 2, 6 * sizeof(GLfloat));
    m_program->enableAttributeArray(0);
    m_program->setAttributeBuffer(1, GL_FLOAT, 2 * sizeof(GLfloat), 4, 6 * sizeof(GLfloat));
    m_program->enableAttributeArray(1);
    //rilascio m_vbo e m_vao
    m_vbo_data.release();
    m_vao_data.release();


    //#######
    //SETUP PER IL DISEGNO DELLE LINEE

    //creazione del vbo per disegnare linee della gliglia
    m_vbo_grid.create();
    m_vbo_grid.bind();

    // unsigned int lines_for_axi = division_for_axi - 1;
    // unsigned int points_for_lines_in_axi = lines_for_axi * 2;


    unsigned int lines_for_v_axi = division_for_vertical_axi - 1;
    double absolute_unit_v_division = 2.0f/division_for_vertical_axi;
    unsigned int points_v_axi = lines_for_v_axi * 2;

    unsigned int lines_for_h_axi = division_for_horizontal_axi - 1;
    double absolute_unit_h_division = 2.0f/division_for_horizontal_axi;
    unsigned int points_h_axi = lines_for_h_axi * 2;

    // faccio un resize e assegno a ogni entità 1.0f, points_for_lines_in_axi viene moltiplicato per due poichè in m_vbo_grid_buffer andranno messe
    // tutte le coordinate dei punti che comporranno la gliglia, quindi sia quelli orizzontali che quelli verticali che sono in egual numero
    m_vbo_grid_buffer.resize( (points_h_axi + points_v_axi) * 6, 0.3f );
    // ora devo scrivere le coordinate dei punti che mi permetteranno di otenere delle linee, è necessario scrivere il buffer in modo tale che si
    // abbiano coordinate che rappresentino i 2 punti per i quali vogliamo che passi la linea. le prime points_for_lines_in_axi * 6 posizioni del vettore
    // sono occupate dalle coordinate che servono per ottenere le linne verticali, le restanti dalle coordinate per ottenere le linee orizzontali

    // k ottenuto come ampiezza totale del range (max - min = 1 - (-1) = 2) fratto il numero di divisioni per asse, in questo caso il numero di divisioni
    // è uguale per entrambi quindi k è valido anche per l'altro caso
    // double k = 2.0f/division_for_axi;

    for(unsigned int i = 0, j=1; i < (points_v_axi + points_h_axi) * 6; i=i+12, j++){

        if(i < points_h_axi * 6){
            //imposto coordinte dei punti per ottenere linee verticali
            m_vbo_grid_buffer[i] = static_cast<GLfloat>(1.0f - (absolute_unit_h_division * j)); //coordinata x del punto 1
            m_vbo_grid_buffer[i+1] = 1.0f;                          //coordinata y del punto 1

            m_vbo_grid_buffer[i+6] = static_cast<GLfloat>(1.0f - (absolute_unit_h_division * j)); //coordinata x del punto 2
            m_vbo_grid_buffer[i+7] = -1.0f;                           //coordinata y del punto 2

        }else{
            //imposto coordinte dei punti per ottenere linee orizzontali
            m_vbo_grid_buffer[i] = 1.0f;
            m_vbo_grid_buffer[i+1] = static_cast<GLfloat>(1.0f - (absolute_unit_v_division * (j - lines_for_h_axi)));

            m_vbo_grid_buffer[i+6] = -1.0f;
            m_vbo_grid_buffer[i+7] = static_cast<GLfloat>(1.0f - (absolute_unit_v_division * (j - lines_for_h_axi)));;
        }
    }

    m_vbo_grid.allocate(&(m_vbo_grid_buffer[0]), (points_v_axi + points_h_axi) * 6 * sizeof(GLfloat));
    // creo vao per disegnare la glriglia
    m_vao_grid.create();
    m_vao_grid.bind();
    //scrittura sul VAO riguardo la modalità di lettura del VBO della griglia, al solito molto importante che
    // in questa fase sia attivo nel contesto solo vbo della gliaglia
    m_program->bind();
    m_program->setAttributeBuffer(0, GL_FLOAT, 0, 2, 6 * sizeof(GLfloat));
    m_program->enableAttributeArray(0);
    m_program->setAttributeBuffer(1, GL_FLOAT, 2 * sizeof(GLfloat), 4, 6 * sizeof(GLfloat));
    m_program->enableAttributeArray(1);
    // rilascio vbo griglia e suo vba
    m_vbo_grid.release();
    m_vao_grid.release();
}

void MyGLWidget::resizeGL(int w, int h)
{
    glViewport(0, 0, w, h);
}

void MyGLWidget::paintGL()
{

    //qDebug()<<"paintGl chiamata";
    //rimozione del frame corrente
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glClear(GL_COLOR_BUFFER_BIT);


    m_program->bind();

    //-----
    // richiamo al contesto m_vbo_grid così da disegnare griglia
    m_vbo_grid.bind();
    m_vao_grid.bind();
    // uso le primitive lines che disegnano una linea di collegamento tra i vertici adiacenti in vbo, offset 0,
    // e il terzo argomento è il numero di vertici da considerare che praticamente sarebbe il numero di linee totali
    //(division_for_axi-1)*2) moltiplicato per 2 poiche ogni linea viene disegnata usando 2 vertici
    glDrawArrays(GL_LINES, 0, (((division_for_vertical_axi-1)*2) + ((division_for_horizontal_axi-1)*2)));

    m_vbo_grid.release();
    m_vao_grid.release();
    //-----


    // richiamo al contesto m_vao e m_vbo per disegnare la sinusoide
    m_vbo_data.bind();
    m_vao_data.bind();
    // cambia primitive per ottenere altre cose con 5000 punti
    glDrawArrays(GL_LINE_STRIP, 0, points * traces);

    m_vbo_data.release();
    m_vao_data.release();
}


// #####################################################################################

// SLOT
void MyGLWidget::modifyTscaleInc(){

    // se if è vero scrivo che non si può più aumentare la scala, si è raggiunto il massimo
    if(t_moltilicator_index == 0){
        emit LogUpdated("Attenzione, il time scale non è stato aumentato perche quello attuale è il massimo imponibile");
        return;
    }
    // altrimenti decremento indice e poi calcolo t_range
    t_moltilicator_index--;
    t_range = t_range_max * t_moltiplicators[t_moltilicator_index];


    // necessario aggiornare anche l'asse dei tempi
    if (realtime_mode == true){
        emit TimeUpdated(setOrderUnit(tot_time_acquisition,"s"),
                         "NOW", setOrderUnit(tot_time_acquisition - t_range,"s"));
    }else{
        // questo caso è un po critico perche senza if seguente da origine ad un bug: se metto modalità statica e poi sposto lo slider a valori bassi e poi
        // aumento molto il time scale si visualizza molto dello schermo nero, non è un errore concettuale quanto più qualcosa che potrebbe
        // confondere, potrei evitare questo problema controllando il risulatato di static_time_acquisition - t_range, se negativo significa che il
        // range che è stato appena impostato è troppo grande, procedo ad "annullarlo" e chiaramente notifico ciò all'utente
        if(static_time_acquisition - t_range < 0){
            t_moltilicator_index++;
            t_range = t_range_max * t_moltiplicators[t_moltilicator_index];

            emit TscaleUpdated(setOrderUnit(t_range/division_for_horizontal_axi,"s"));

            emit LogUpdated("Attenzione, il time scale NON è stato aumentato per evitare artefatto grafico");
        }
        emit TimeUpdated(setOrderUnit(instant_tot_time_acquisition,"s"),
                         setOrderUnit(static_time_acquisition, "s"), setOrderUnit(static_time_acquisition - t_range,"s"));
    }

    emit TscaleUpdated(setOrderUnit(t_range/division_for_horizontal_axi, "s"));



}

void MyGLWidget::modifyTscaleDec(){
    // se if è vero scrivo che non si può più diminuire la scala, si è raggiunto il minimo, notare che questo limite è dato dal solo fatto
    // che il vettore con i coefficienti moltiplicativi è lungo 6, se ne metto altri non c sono problemi di artefatti da gestire
    if(t_moltilicator_index == t_moltiplicators.size()-1){
        emit LogUpdated("Attenzione, il time scale non è stato diminuito perche quello attuale è il minimo imponibile");
        return;
    }
    // altrimenti incremento indice e poi calcolo t_range
    t_moltilicator_index++;
    t_range = t_range_max * t_moltiplicators[t_moltilicator_index];

    emit TscaleUpdated(setOrderUnit(t_range/division_for_horizontal_axi,"s"));

    if (realtime_mode == true){

        emit TimeUpdated(setOrderUnit(tot_time_acquisition,"s"),
                         "NOW", setOrderUnit(tot_time_acquisition - t_range,"s"));

    }else {

        emit TimeUpdated(setOrderUnit(instant_tot_time_acquisition,"s"),
                         setOrderUnit(static_time_acquisition, "s"), setOrderUnit(static_time_acquisition - t_range, "s"));
    }


}

void MyGLWidget::modifyVscaleInc(){

    if(v_moltilicator_index == 0){
        emit LogUpdated("Attenzione, il vertical scale non è stato aumentato perche quello attuale è il massimo imponibile");
        return;
    }
    // altrimenti decremento indice e poi calcolo le due nuove soglie
    v_moltilicator_index--;
    v_sup = v_max * v_moltiplicators[v_moltilicator_index];
    v_inf = v_min * v_moltiplicators[v_moltilicator_index];

    emit VscaleUpdated(setOrderUnit((v_sup - v_inf)/division_for_vertical_axi, v_measure_unit),
                       setOrderUnit(v_sup, v_measure_unit), setOrderUnit(v_inf, v_measure_unit));

}

void MyGLWidget::modifyVscaleDec(){

    if(v_moltilicator_index == v_moltiplicators.size()-1){
        emit LogUpdated("Attenzione, il vertical scale non è stato diminuito perche quello attuale è il minimo imponibile");
        return;
    }
    // altrimenti incremento indice e poi calcolo le due nuove soglie
    v_moltilicator_index++;
    v_sup = v_max * v_moltiplicators[v_moltilicator_index];
    v_inf = v_min * v_moltiplicators[v_moltilicator_index];

    emit VscaleUpdated(setOrderUnit((v_sup - v_inf)/division_for_vertical_axi, v_measure_unit),
                       setOrderUnit(v_sup, v_measure_unit), setOrderUnit(v_inf, v_measure_unit));
}


void MyGLWidget::modifyTimeWindow(int val){
    // controllo per assicurare che l'oggetto sia stato impostato per lavorare in modalità statica e anche che val sia compreso tra 0 e 100
    // (esclusi)
    if(realtime_mode == true) return;
    if((val > 100) || (val < 0)) return;

    // calcolo del tempo di acquisizione statico e indice rispetto al quale iniziare a prendere i campioni
    static_time_acquisition  = instant_tot_time_acquisition * (val/100.0);
    index_static_tail_data_buffer = static_cast<unsigned int>((val/100.0) * instant_index_tail_data_buffer);

    //controllo per evitare che si vada avisualizzare la prima parte di taracciato, quella dove il segnale è disegnato
    // solo a sinistra dello schermo
    if((static_time_acquisition < t_range)&&(tot_time_acquisition > t_range)){
        static_time_acquisition = t_range;
        // è un buon modo tuttavia fa molto affidamento sul fatto che la fc sia molto costante, è sicuro calcolarsi index_static_tail_data_buffer
        // solo se è passato un tempo almeno pari a t_range (magari sarebbe meglio avere anche qualcosa in più perche realisticamente la fc non è perfet
        // tamente costante) in caso contrario index_static_tail_data_buffer assume un valore maggiore della lunghezza di data_buffer e chiaramente
        // si verifica crash
        index_static_tail_data_buffer = static_cast<unsigned int>(t_range/(1/fc));
    }else if(tot_time_acquisition <= t_range){
        // in questo caso ricalcolare index_static_tail_data_buffer non è fattibile, avviso con un log che potrebbero verificarsi artefatti grafici
        emit LogUpdated("Attenzione il time scale impostato potrebbe dare origine ad artefatti grafici, diminuirlo provvisioramente.");
    }


    // emit TimeUpdated(QString::number(static_time_acquisition,'d',3),
    //                  QString::number(static_time_acquisition,'d',3), QString::number(static_time_acquisition - t_range,'d',3));

    emit TimeUpdated(setOrderUnit(instant_tot_time_acquisition,"s"),
                     setOrderUnit(static_time_acquisition,"s"), setOrderUnit(static_time_acquisition - t_range,"s"));
    emit LogUpdated("Changed time window in static mode");




}

void MyGLWidget::modifyMod(bool m){
    // ricorda che lo stato del pulsante cambia nell'istante in cui viene premuto, inizialmente il
    // pulsante è non premuto quindi la prima pressione sarà un true
    if(m == true){
        // modalità statica
        realtime_mode = false;
        instant_index_tail_data_buffer = index_tail_data_buffer;
        instant_tot_time_acquisition = tot_time_acquisition;
        // importante garantire che l'indice statico sia identico a quello di data buffer istantaneo,
        // bisogna farlo a questo livello e non nella change vertex perchè già lì data_buffer è aumentato di
        // lunghezza, quindi la pressione del pulsante mosrerebbe un pezzo di tracciato ulteriore.
        index_static_tail_data_buffer = instant_index_tail_data_buffer;
        //"inizializzazione" di static_time_acquisition, è necessaria perchè altrimenti se passo in modalità statica e modifico subito time scale ottengo
        // bug perche static_time_acquisition non è ancora stato definito in modo adeguato
        static_time_acquisition = tot_time_acquisition;

        // emit TimeUpdated(QString::number(instant_tot_time_acquisition,'d',3),
        //                  QString::number(instant_tot_time_acquisition,'d',3),QString::number(instant_tot_time_acquisition - t_range,'d',3));
        emit TimeUpdated(setOrderUnit(instant_tot_time_acquisition,"s"),
                         setOrderUnit(instant_tot_time_acquisition,"s"),setOrderUnit(instant_tot_time_acquisition - t_range,"s"));
        emit ModUpdated("Static Instant Time");
        emit LogUpdated("Static mode actived");

    }else{
        // modalità dinamica
        realtime_mode = true;
        // emit TimeUpdated(QString::number(tot_time_acquisition,'d',3),
        //                  "NOW", QString::number(tot_time_acquisition-t_range,'d',3));
        emit TimeUpdated(setOrderUnit(tot_time_acquisition,"s"),
                         "NOW", setOrderUnit(tot_time_acquisition - t_range,"s"));
        emit ModUpdated("Total time acquisition");
        emit LogUpdated("Real-time mode actived");
    }
}


void MyGLWidget::modifyFilterMod(bool m){
    // ricorda che lo stato del pulsante cambia nell'istante in cui viene premuto, inizialmente il
    // pulsante è non premuto quindi la prima pressione sarà un true
    if(m == true){
        // pulsante premuto, applico il filtro
        filter_mode = true;
        emit LogUpdated("High-pass filter activated");

    }else{
        // pulsante rilasciato, tolgo il filtro
        filter_mode = false;
        emit LogUpdated("High-pass filter disabled");
    }
}


// funzione per gestire gli ordini delle unità di misura, in pratica controlla se l'unità inserita è scalabile e nel caso ne restituisce la stringa
// e il dato opportunamente scalati
QString MyGLWidget::setOrderUnit(double data, QString ref_unit){
    // vettore che contiene delle strighe che rappresentano le unità di misura scalabili, sono riportate in unità base perchè poi questa viene utilizzata
    // per ottenere i vari ordini della stessa.
    QStringList const scalable_units = {"V", "s"};
    QStringList const order_units = {"k", "M",
                                     "m", "µ", "n", "p"};

    // controllo se nel vettore di unità supportate ce quella data con il parametro, in caso contrario restituisco tutto senza effetuare modifice all
    // unita di misura e al dato
    if(!scalable_units.contains(ref_unit)) return QString::number(data, 'e',3) + " " + ref_unit;

    // controllo il valore di data, se 0 esco subito
    if(data == 0) return QString::number(data, 'd',0) + " " + ref_unit;

    QString unit = ref_unit;

    // controllo se il numero è negativo, nel caso lo riporto positivo perchè semplifica gli if per applicare
    // la scalatura
    double negative = 1;
    if(data < 0){
        data = data*(-1);
        negative = -1;
    }

    // applico la scalatura per evitare di avere valori del tipo 0.x e del tipo xxxxx
    if(data < 1){
        // caso in cui il dato è minore di 1, servono unità di misura più piccole
        data = data * 1e3;
        int i = 2;
        while((data < 1) && (i < 6)){
            data = data * 1e3;
            i++;
        }
        if (i < 6) return QString::number(data * negative, 'd',3) + " " + order_units[i] + unit;
        // se i = 6 significa che data continua a restare minore di 0.001, restituisco il dato con l'unità scalata ma ho bisogno anche
        // della notazione scientifica perche il dato è ancora molto piccolo
        else return QString::number(data * negative, 'e',3) + " " + order_units[5] + unit;

    }else if (data > 1000){
        // caso in cui il dato è maggiore di 1000
        data = data * 1e-3;
        int i = 0;
        while((data > 10) && (i < 2)){
            data = data * 1e-3;
            i++;
        }
        if (i < 2) return QString::number(data * negative, 'd',3) + " " + order_units[i] + unit;
        // caso analogo a prima però nell'altra direzione, cioè il dato è ancora molto grande
        else return QString::number(data * negative, 'e',3) + " " + order_units[0] + unit;

    }else{
        // l'unità è scalabile ma il dato non ha bisogno di essere scalato
        return QString::number(data * negative, 'd',3) + " " + unit;
    }

}



// ######################################################################################



