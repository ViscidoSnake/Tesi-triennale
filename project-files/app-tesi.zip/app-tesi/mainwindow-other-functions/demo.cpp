

#include "../mainwindow.h"
#include "ui_mainwindow.h"


void MainWindow::demo(){

    demo_mode = true;

    // quando si avvia demo tutta l'interfaccia di connessione viene bloccata in modo perenne, l'unico modo è chidere e riavviare l'applicazione
    ui->tabs->setCurrentIndex(1);
    ui->tabs->tabBar()->setEnabled(false);

    decoders_setup_data s;
    s.config = unsigned(773589556);
    s.channels = 3;
    s.datarateEMG = 800;
    s.datarateGYR = 104.167;
    s.gyr_range = 8;
    s.acc_range = 500;

    this->setupGLscreens(s);

    //fileGYR.setFileName("C:\\Users\\snake\\Desktop\\app-tesi\\mainwindow-other-functions\\GYR.txt");
    //apertura del file
    fileGYR.setFileName(":/mainwindow-other-functions/GYR.txt");
    if (!fileGYR.open(QIODevice::ReadOnly | QIODevice::Text)) {
        //caso errore
        qDebug() << "Errore nell'apertura del file:" << fileGYR.errorString();
        return;
    }
    // variabile usata per la lettura
    streamGYR = new QTextStream(&fileGYR);


    // fileEMG.setFileName("C:\\Users\\snake\\Desktop\\app-tesi\\mainwindow-other-functions\\EMG.txt");
    fileEMG.setFileName(":/mainwindow-other-functions/EMG.txt");
    if (!fileEMG.open(QIODevice::ReadOnly | QIODevice::Text)) {
        //caso errore
        qDebug() << "Errore nell'apertura del file:" << fileEMG.errorString();
        return;
    }
    // variabile usata per la lettura
    streamEMG = new QTextStream(&fileEMG);


    // #####################################################################################
    // simulazione arrivo dati, start del timer che innesca lettura di una riga del file aperto ogni 10 ms
    timer_data = new QTimer(this);
    // connessione segnali agli slot per riempimento dei data buffer
    connect(timer_data, &QTimer::timeout, this, &MainWindow::demoIndataEMG);
    connect(timer_data, &QTimer::timeout, this, &MainWindow::demoIndataGYR);
    timer_data->start(10);
    // #####################################################################################

}


void MainWindow::demoIndataGYR() {
    static bool initialized = false;
    static double t0_file;
    // si riporta il tempo in secondi essend restituito dalla funzione in millisecondi
    double now = QDateTime::currentMSecsSinceEpoch() * 0.001;

    while (true)
        if (!streamGYR->atEnd()) {
            QString line = streamGYR->readLine();

            // qDebug() << "Riga letta: " << line;

            // stringa associata ad un dato da EMG, divido il dato in gruppetti ciascuno dei quali andrà poi inviato
            // alcorretto buffer
            QStringList str_list = line.split(" ", Qt::SkipEmptyParts);

            //stringa associata ad un dato GYR
            smp smpch1 = {str_list[0].toFloat(), {str_list[1].toFloat()}};
            smp smpch2 = {str_list[0].toFloat(), {str_list[5].toFloat(), str_list[6].toFloat(), str_list[7].toFloat()}};
            smp smpch3 = {str_list[0].toFloat(), {str_list[2].toFloat(), str_list[3].toFloat(), str_list[4].toFloat()}};


            if (!initialized) {
                t0_file = now - smpch3.tm;
                initialized = true;
            }

            emit this->demoGYRtempData(smpch1);
            // qDebug()<< QString::number(smpch1.val[0]);
            emit this->demoGYRaccData(smpch2);
            emit this->demoGYRvelData(smpch3);

            if (smpch3.tm + t0_file > now) break;

        } else {
            // file.seek(0);
            // qDebug() << "lettura del file terminata!";
            initialized = false;
            return;
        }
}


void MainWindow::demoIndataEMG() {
    static bool initialized = false;
    static double t0_file;
    // si riporta il tempo in secondi essend restituito dalla funzione in millisecondi
    double now = QDateTime::currentMSecsSinceEpoch() * 0.001;

    while (true)
        if (!streamEMG->atEnd()) {
            QString line = streamEMG->readLine();

            // qDebug() << "Riga letta: " << line;

            // stringa associata ad un dato da EMG, divido il dato in gruppetti ciascuno dei quali andrà poi inviato
            // alcorretto buffer
            QStringList str_list = line.split(" ", Qt::SkipEmptyParts);

            //stringa associata ad un dato EMG
            smp smpch1 = {str_list[0].toFloat(), {str_list[1].toFloat()}};
            smp smpch2 = {str_list[0].toFloat(), {str_list[2].toFloat()}};
            smp smpch3 = {str_list[0].toFloat(), {str_list[3].toFloat()}};

            if (!initialized) {
                t0_file = now - smpch3.tm;
                initialized = true;
            }

            emit this->demoEMGch1Data(smpch1);
            emit this->demoEMGch2Data(smpch2);
            emit this->demoEMGch3Data(smpch3);

            if (smpch3.tm + t0_file > now) break;

        } else {
            // file.seek(0);
            // qDebug() << "lettura del file terminata!";
            initialized = false;
            return;
        }
}






















